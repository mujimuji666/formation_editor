import flet as ft
from PIL import Image
import requests
from io import BytesIO
import sqlite3
import datetime as dt

from behinds.constants import CIRCLE_DIAMETER, TEXT_SIZE, WAKU_COLORS, TRACK_IMAGE_URL_DICT, SURFACE_IMAGE_URL_DICT, SPLIT_INDEX_DICT, MIN_SPLIT_INDEX, ROOT_HEIGHT, TOTAL_HORSE_NUM, FORMATION_PANEL_RATIO, CONTAINER_PADDING, ROOT_IMAGE_WIDTH, ROOT_IMAGE_HEIGHT, ROOT_IMAGE_CELL, ROOT_IMAGE_OUTER_PIXNUM, ROOT_IMAGE_HEAD_PIXNUM, ROOT_IMAGE_CENTER_LINE_WIDTH, ROOT_IMAGE_SUB_LINE_WIDTH, ROOT_FORMATION_PANEL_HEIGHT, ROOT_SELECT_PANEL_ASPECT_RATIO, ROOT_IMAGE_ASPECT_RATIO, ROOT_FORMATION_PANEL_ASPECT_RATIO, ROOT_FORMATION_FRONT_PADDING, ROOT_FORMATION_BACK_PADDING, ROOT_FORMATION_INNER_PADDING, ROOT_FORMATION_OUTER_PADDING, CIRCLE_PADDING, CIRCLE_RADIUS, YOUBI_CARACTER_LIST

from behinds.parts import FormationHorseChip, MenuHorseButton, RaceMenuBar
from behinds.functions import Generate_umaban2waku_map
from behinds.data_struct import RaceID

def save_to_sqlite(data_list: list[dict]):
    """馬の比率座標データを SQLite ファイルへ保存する"""
    conn = sqlite3.connect("formation.db")
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS positions (
            makedatetime TEXT,
            race_id TEXT,
            horse_number INTEGER,
            mode TEXT,
            x REAL,
            y REAL,
            edit_x REAL,
            edit_y REAL
        )
    """)
    cursor.execute("DELETE FROM positions WHERE race_id = ?", (data_list[0]["race_id"],))  # 上書きのためリセット
    for data in data_list:
        cursor.execute(
            "INSERT INTO positions VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (data["makedatetime"], data["race_id"], data["horse_number"], data["mode"], data["x"], data["y"], data["edit_x"], data["edit_y"])
        )
    conn.commit()
    conn.close()

def load_from_sqlite(race_id:RaceID) -> list[dict]:
    """SQLite からデータを読み込んで辞書のリストにして返す"""
    conn = sqlite3.connect("formation.db")
    cursor = conn.cursor()
    data_list = []
    try:
        cursor.execute("SELECT makedatetime, race_id, horse_number, mode, x, y, edit_x, edit_y FROM positions WHERE race_id = ?", (race_id.race_id,))
        for row in cursor.fetchall():
            data_list.append({
                "makedatetime": row[0],
                "race_id": row[1],
                "horse_number": row[2],
                "mode": row[3],
                "x": row[4],
                "y": row[5],
                "edit_x": row[6],
                "edit_y": row[7]
            })
    except sqlite3.OperationalError:
        pass  # 初回起動時などでテーブルがない場合は空リスト
    conn.close()
    return data_list

class FormationEditor(ft.Container):
    #-------------------------------------------------------------
    # 1. コンストラクタ
    #-------------------------------------------------------------
    def __init__(self, 
                 total_horses=TOTAL_HORSE_NUM, turn="右", surface="ダート", 
                 height = ROOT_HEIGHT, 
                 **kwargs):
        
        # レース条件
        self._set_first_race_id()
        self.total_horses = total_horses
        self.turn = turn
        self.surface = surface
        self.waku_map = Generate_umaban2waku_map(total_horses)
        
        # 見た目用変数の初期化
        
        # 各コントロールのサイズ規定
        self.container_height  = height
        self.panel_height      = self.container_height - CONTAINER_PADDING * 2
        
        self.select_panel_width = self.panel_height * ROOT_SELECT_PANEL_ASPECT_RATIO
        self.select_panel_height = self.panel_height
        
        self.formation_panel_width = self.select_panel_width * FORMATION_PANEL_RATIO
        self.formation_panel_height = self.formation_panel_width * ROOT_FORMATION_PANEL_ASPECT_RATIO
        
        self.display_panel_width = self.formation_panel_width
        self.display_panel_height = self.panel_height - self.formation_panel_height - CONTAINER_PADDING
        
        # 画像のURLを取得
        self.track_image_url = TRACK_IMAGE_URL_DICT[self.turn]
        self.surface_image_url = SURFACE_IMAGE_URL_DICT[self.surface]
        
        # 画像のサイズ規定
        response = requests.get(self.track_image_url)
        bg_image = Image.open(BytesIO(response.content))
        if bg_image.width != ROOT_IMAGE_WIDTH or bg_image.height != ROOT_IMAGE_HEIGHT:
            raise ValueError(f"Track image size is not as expected: {bg_image.size}")
        else:
            self.root_bg_image_width  = ROOT_IMAGE_WIDTH
            self.root_bg_image_height = ROOT_IMAGE_HEIGHT
            self.root_bg_image_aspect_ratio = ROOT_IMAGE_ASPECT_RATIO
            self.root_bg_formation_panel_height = ROOT_FORMATION_PANEL_HEIGHT
            self.root_bg_formation_front_padding = ROOT_FORMATION_FRONT_PADDING
            self.root_bg_formation_back_padding  = ROOT_FORMATION_BACK_PADDING
            self.root_bg_formation_inner_padding = ROOT_FORMATION_INNER_PADDING
            self.root_bg_formation_outer_padding = ROOT_FORMATION_OUTER_PADDING
        
        self.bg_image_scale_ratio = self.formation_panel_width / self.root_bg_image_width
        
        self.bg_image_width  = self.root_bg_image_width * self.bg_image_scale_ratio
        self.bg_image_height = self.root_bg_image_height * self.bg_image_scale_ratio
        self.bg_image_slide_height = self.bg_image_height - self.formation_panel_height
        
        self.formation_outer_padding = self.root_bg_formation_outer_padding * self.bg_image_scale_ratio + CIRCLE_PADDING + CIRCLE_RADIUS
        self.formation_inner_padding = self.root_bg_formation_inner_padding * self.bg_image_scale_ratio + CIRCLE_PADDING + CIRCLE_RADIUS
        self.formation_front_padding = self.root_bg_formation_front_padding * self.bg_image_scale_ratio + CIRCLE_PADDING + CIRCLE_RADIUS
        self.formation_back_padding  = self.root_bg_formation_back_padding  * self.bg_image_scale_ratio + CIRCLE_PADDING + CIRCLE_RADIUS
        
        self.upper_limit_dict = {
            "mukojomen": self.formation_outer_padding,
            "chokusen":  self.formation_inner_padding
        }
        
        self.under_limit_dict = {
            "mukojomen": self.formation_panel_height - self.formation_inner_padding,
            "chokusen":  self.formation_panel_height - self.formation_outer_padding
        }
        
        self.left_limit_dict = {
            "右": {"mukojomen": self.formation_back_padding,  "chokusen": self.formation_front_padding},
            "左": {"mukojomen": self.formation_front_padding, "chokusen": self.formation_back_padding},
        }
        self.right_limit_dict = {
            "右": {"mukojomen": self.formation_panel_width - self.formation_front_padding, 
                    "chokusen":  self.formation_panel_width - self.formation_back_padding},
            "左": {"mukojomen": self.formation_panel_width - self.formation_back_padding, 
                    "chokusen":  self.formation_panel_width - self.formation_front_padding},
        }
 
        # 状態変数の初期化
        self.active_chip = None
        self.current_mode = "mukojomen"
        
        # 馬番選択ボタン群の初期化
        self.menu_buttons_muko = self._create_menu_buttons()
        self.menu_buttons_choku = self._create_menu_buttons()
        self.menu_buttons = self.menu_buttons_muko
        
        # モード切替ボタンの初期化
        self.mode_button = ft.FilledButton("向正面", on_click=self.toggle_mode, height=30)
        
        # 左パネル（馬番選択ボタン群）の初期化
        self.umaban_select_muko = self._build_umaban_select_col(self.menu_buttons_muko)
        self.umaban_select_choku = self._build_umaban_select_col(self.menu_buttons_choku)
        
        self.menu_buttons_col_container = ft.Container(
            content=self.umaban_select_muko,
            border_radius=8,
            bgcolor=ft.Colors.SURFACE_CONTAINER_LOW,
            width=self.select_panel_width, height=self.select_panel_height,
            padding=10,
        )
        
        # 右上パネル（隊列図スタック）の初期化
        self.surface_image_layer = ft.Image(
            src=self.surface_image_url, fit=ft.BoxFit.FIT_WIDTH,
            width=self.bg_image_width, height=self.bg_image_height,
            top=0,
            )
        self.track_image_layer = ft.Image(
            src=self.track_image_url, fit=ft.BoxFit.FIT_WIDTH,
            width=self.bg_image_width, height=self.bg_image_height,
            top=0
            )
        
        self.chip_layer_muko = ft.Stack(
            width=self.formation_panel_width, height=self.formation_panel_height, top=0, visible=True)
        self.chip_layer_choku = ft.Stack(
            width=self.formation_panel_width, height=self.formation_panel_height, top=0, visible=False)
        
        self.chip_layer = self.chip_layer_muko  # アクティブなチップレイヤーを保持
        
        self.control_layer = ft.GestureDetector(on_tap_down=self.image_click)

        self.formation_area = ft.Stack(
            controls=[
                self.surface_image_layer,
                self.track_image_layer,
                self.control_layer,
                self.chip_layer_muko,
                self.chip_layer_choku,
            ],
        )
        
        self.formation_area_container = ft.Container(
                content=self.formation_area,
                bgcolor=ft.Colors.RED,
                border_radius=8,
                width=self.formation_panel_width,
                height=self.formation_panel_height, # test
            )
        
        # 右下パネル（レース情報パネル）の初期化
        text_content = "レース情報パネル\n日付、場名、レース番号の選択\n馬番の選択、馬名の表示\n選択馬番の馬主服表示\n"
        
        self.race_id_status_text = ft.Text(
            "Race ID: 未設定\n" + "\n" + text_content, 
            size=14, weight=ft.FontWeight.BOLD, color=ft.Colors.BLUE_400, expand=True,
            text_align=ft.TextAlign.START, 
        )
        
        self.select_container = RaceMenuBar(
            race_id = self.race_id,
            on_race_id_change=self._handle_menu_race_id_change,
        )
        
        self.function_buttons_col = ft.Column(
            controls=[
                self.mode_button,
                ft.FilledButton(" 保存 ", on_click=lambda e: save_to_sqlite(self.get_current_chip_positions()), height=30),
                ft.FilledButton(" 読込 ", on_click=lambda e: self.load_chip_positions(load_from_sqlite(self.race_id)), height=30),
                ],
            alignment=ft.MainAxisAlignment.START,
            width=100,
            spacing=5,
        )   
        
        display_panel_col = ft.Column(
            controls=[
                self.select_container,
                ft.Row(
                    controls=[self.race_id_status_text, self.function_buttons_col],
                    vertical_alignment=ft.CrossAxisAlignment.START,
                ),
            ],
            alignment=ft.CrossAxisAlignment.START,
            horizontal_alignment=ft.CrossAxisAlignment.START,
        )
        
        self.display_panel = ft.Container(
            content=display_panel_col,
            width=self.display_panel_width, height=self.display_panel_height,
            bgcolor=ft.Colors.SURFACE_CONTAINER_LOW,
            border_radius=8,
        )
        
        # 右パネル（隊列図スタック＋レース情報パネル）のレイアウト
        self.right_panels_col = ft.Column(
            controls=[
                self.formation_area_container,
                self.display_panel,
            ],
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=10
        )

        # 全体レイアウトの初期化
        editor_layout = ft.Row(
            controls=[
                self.menu_buttons_col_container, 
                self.right_panels_col,
                ],
            alignment=ft.MainAxisAlignment.CENTER, 
            vertical_alignment=ft.CrossAxisAlignment.CENTER)
        
        # コンテナの初期化
        super().__init__(
            content=editor_layout,
            width=self.select_panel_width + self.formation_panel_width + CONTAINER_PADDING * 3,
            height=self.container_height,
            bgcolor=ft.Colors.SURFACE_CONTAINER_HIGHEST,
            border_radius=16,
            padding=CONTAINER_PADDING,
            **kwargs
        )
        
        print(f"Container width: {self.width}, height: {self.height}")
        print(f"Menu buttons col panel width: {self.menu_buttons_col_container.width}, height: {self.menu_buttons_col_container.height}")
        print(f"Formation panel width: {self.formation_area_container.width}, height: {self.formation_area_container.height}")
        
    # -------------------------------------------------------------
    # 2. コンストラクタ補助関数（プライベート関数）
    # -------------------------------------------------------------
    def _create_menu_buttons(self) -> dict[int, MenuHorseButton]:
        return {
            i: MenuHorseButton(
                horse_number=i, waku_map=self.waku_map,
                on_click=lambda e, horse_number=i: self.on_umaban_select(horse_number)
            ) for i in range(1, self.total_horses+1)
        }
           
    def _build_umaban_buttons_col_list(self, menu_buttons_dict) -> list[ft.Row]:
        if self.total_horses <= MIN_SPLIT_INDEX:
            return [ft.Column(
                controls=list(menu_buttons_dict.values()), 
                alignment=ft.MainAxisAlignment.CENTER, spacing=5)]
        else:
            split_index = SPLIT_INDEX_DICT.get(self.total_horses, self.total_horses // 2)
            return [
                ft.Column(
                    controls=list(menu_buttons_dict.values())[split_index:], 
                    alignment=ft.MainAxisAlignment.CENTER, spacing=5),
                ft.Column(
                    controls=list(menu_buttons_dict.values())[:split_index], 
                    alignment=ft.MainAxisAlignment.CENTER, spacing=5)
            ]
            
    def _build_umaban_select_col(self, menu_buttons_dict):
        umaban_buttons_col_list = self._build_umaban_buttons_col_list(menu_buttons_dict)
                
        return ft.Column(
            controls=[
                ft.Row(
                    controls=umaban_buttons_col_list,
                    alignment=ft.MainAxisAlignment.CENTER,
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                    expand=True,
                    spacing=5,
                ),
            ],
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=10,
        )
        
    # -------------------------------------------------------------
    # 3. イベント関数
    # -------------------------------------------------------------
    def toggle_mode(self, e: ft.Event[ft.Button]):
        if self.current_mode == "mukojomen":
            self.current_mode = "chokusen"
            self.menu_buttons = self.menu_buttons_choku
            self.menu_buttons_col_container.content = self.umaban_select_choku
            self.mode_button.content = "直線"
            self.surface_image_layer.top = -self.bg_image_slide_height
            self.track_image_layer.top = -self.bg_image_slide_height
            self.chip_layer_muko.visible = False
            self.chip_layer_choku.visible = True
            self.chip_layer = self.chip_layer_choku
        else:
            self.current_mode = "mukojomen"
            self.menu_buttons = self.menu_buttons_muko
            self.menu_buttons_col_container.content = self.umaban_select_muko
            self.mode_button.content = "向正面"
            self.surface_image_layer.top = 0
            self.track_image_layer.top = 0
            self.chip_layer_muko.visible = True
            self.chip_layer_choku.visible = False
            self.chip_layer = self.chip_layer_muko
        self.update()      
    
    def formation_chip_on_tap_down(self, e: ft.Event[ft.Container]):
        if self.active_chip is not None:
            self.active_chip.set_selected(False)
        self.active_chip = e.control
        self.active_chip.set_selected(True)
        self.update()
    
    def formation_chip_on_double_tap(self, e: ft.Event[ft.Container]):
        target_chip = e.control
        removed_number = target_chip.text_control.value
        if removed_number != "✕":
            self.menu_buttons[int(removed_number)].set_enabled(True)
        if target_chip == self.active_chip:
            self.active_chip = None 
        self.chip_layer.controls.remove(target_chip)
        self.update()
        
    def image_click(self, e: ft.Event[ft.TapEvent[ft.GestureDetector]]):
        clicked_position = e.local_position
        
        left, top = self.calc_position_by_limit(clicked_position.x, clicked_position.y)
        
        new_temp_horse = FormationHorseChip(
            horse_number=0,
            calc_limit_func=self.calc_position_by_limit,
            waku_map=self.waku_map,
            left=left, top=top,
            on_tap_down=self.formation_chip_on_tap_down,
            on_double_tap=self.formation_chip_on_double_tap
        )
        
        self.chip_layer.controls.append(new_temp_horse)

        if self.active_chip is not None:
            self.active_chip.set_selected(False)
        self.active_chip = new_temp_horse
        self.active_chip.set_selected(True)
        
    def get_current_chip_positions(self) -> list[dict]:
        data_list = []
        for chip in self.chip_layer_muko.controls:
            data_list.append({
                "makedatetime": dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "race_id": self.race_id.race_id,
                "horse_number": int(chip.text_control.value) if chip.text_control.value != "✕" else 0,
                "waku_number":  chip.waku_number,
                "mode": "mukojomen",
                "x": (chip.left + CIRCLE_DIAMETER / 2) / self.bg_image_width,
                "y": (chip.top + CIRCLE_DIAMETER / 2) / self.bg_image_height,
                "edit_x": (chip.left + CIRCLE_DIAMETER / 2) / self.bg_image_width,
                "edit_y": (chip.top + CIRCLE_DIAMETER / 2) / self.bg_image_height,
            })
        for chip in self.chip_layer_choku.controls:
            data_list.append({
                "makedatetime": dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "race_id": self.race_id.race_id,
                "horse_number": int(chip.text_control.value) if chip.text_control.value != "✕" else 0,
                "waku_number":  chip.waku_number,
                "mode": "chokusen",
                "x": (chip.left + CIRCLE_DIAMETER / 2) / self.bg_image_width,
                "y": (chip.top + CIRCLE_DIAMETER / 2 + self.bg_image_slide_height) / self.bg_image_height,
                "edit_x": (chip.left + CIRCLE_DIAMETER / 2) / self.bg_image_width,
                "edit_y": (chip.top + CIRCLE_DIAMETER / 2) / self.bg_image_height,
            })
        return data_list
    
    def load_chip_positions(self, data_list: list[dict]) -> None:
        self.chip_layer_muko.controls.clear()
        self.chip_layer_choku.controls.clear()
        
        for data in data_list:
            horse_number = data["horse_number"]
            mode = data["mode"]
            x = data["edit_x"] * self.bg_image_width
            y = data["edit_y"] * self.bg_image_height
            
            if mode == "mukojomen":
                left, top = self.calc_position_by_limit(x, y)
                new_chip = FormationHorseChip(
                    horse_number=horse_number,
                    calc_limit_func=self.calc_position_by_limit,
                    waku_map=self.waku_map,
                    left=left, top=top,
                    on_tap_down=self.formation_chip_on_tap_down,
                    on_double_tap=self.formation_chip_on_double_tap
                )
                self.chip_layer_muko.controls.append(new_chip)
            elif mode == "chokusen":
                left, top = self.calc_position_by_limit(x, y)
                new_chip = FormationHorseChip(
                    horse_number=horse_number,
                    calc_limit_func=self.calc_position_by_limit,
                    waku_map=self.waku_map,
                    left=left, top=top,
                    on_tap_down=self.formation_chip_on_tap_down,
                    on_double_tap=self.formation_chip_on_double_tap
                )
                self.chip_layer_choku.controls.append(new_chip)
        
        self.update()
        
    def _set_first_race_id(self):
        today = dt.date.today()
        self.race_id = RaceID(today, "東京", 1, 1, 1)  # 初期化
        
    def _handle_menu_race_id_change(self, new_race_id: RaceID):
        if self.chip_layer_muko.controls or self.chip_layer_choku.controls:
            save_to_sqlite(self.get_current_chip_positions())  # 現在のデータを保存
        self.chip_layer_muko.controls.clear()
        self.chip_layer_choku.controls.clear()
        self.race_id = new_race_id
        self.race_id_status_text.value = f"Race ID: {self.race_id.race_id}\n\n日付: {self.race_id.date}, 場名: {self.race_id.jyo}, レース番号: {self.race_id.race_num}R, 回次: {self.race_id.kaiji}回, 日次: {self.race_id.nichiji}日"
        self.update()
        
    # -------------------------------------------------------------
    # 4. イベント補助関数
    # -------------------------------------------------------------
    def calc_position_by_limit(self, root_x, root_y):
        self.upper_limit = self.upper_limit_dict[self.current_mode]
        self.under_limit = self.under_limit_dict[self.current_mode]
        self.left_limit = self.left_limit_dict[self.turn][self.current_mode]
        self.right_limit = self.right_limit_dict[self.turn][self.current_mode]
        
        root_x = self.left_limit if root_x < self.left_limit else root_x if root_x < self.right_limit else self.right_limit
        root_y = self.upper_limit if root_y < self.upper_limit else root_y if root_y < self.under_limit else self.under_limit
            
        output_x = root_x - CIRCLE_DIAMETER / 2
        output_y = root_y - CIRCLE_DIAMETER / 2
        
        return output_x, output_y

    def on_umaban_select(self, horse_number: int):
        if self.active_chip is None:
            return

        old_number = self.active_chip.text_control.value
        if old_number != "✕":
            self.menu_buttons[int(old_number)].set_enabled(True)
        
        self.active_chip.set_selected(False)
        self.active_chip.set_horse_number(horse_number)

        self.menu_buttons[horse_number].set_enabled(False)

        self.update()
    

def main(page: ft.Page):
    page.title = "隊列図テスト"
    position_dict = {}
    
    def apply_resize(e: ft.Event[ft.Page]):
        page.clean()
        
        print(f"Page width: {page.width}, height: {page.height}")
        
        if page.width < page.height:
            text_container = ft.Container(
                content=ft.Text("画面が縦長です。\n横長にしてご利用ください。", size=20, text_align=ft.TextAlign.CENTER),
                alignment=ft.Alignment.CENTER,
                expand=True
            )
            page.add(text_container)
        else:
            
            padding_container = ft.Container(
                width=50, height=page.height-20
            )
            
            formation_editor = FormationEditor(
                turn="右", surface="ダート", total_horses=18, 
                height=page.height - 20
            )
            final_container = ft.Container(
                content=ft.Row(
                    controls=[
                        padding_container,
                        formation_editor,
                        ]),
                alignment=ft.Alignment.CENTER,
            )
            page.add(final_container)
    
    page.on_resize = apply_resize
    apply_resize(None)  # 初期表示時に呼び出す
                
    
# -------------------------------------------------------------
# アプリの起動
# -------------------------------------------------------------

if __name__ == "__main__":
    ft.run(main)