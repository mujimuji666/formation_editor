import flet as ft
from PIL import Image
import requests
from io import BytesIO

def Generate_umaban2waku_map(total_horses: int) -> dict[int, int]:
    """馬番から枠番へのマッピングを生成する"""
    if total_horses <= 8:
        waku_map = {i: i for i in range(0, total_horses + 1)}
    elif total_horses <= 16:
        append = total_horses - 8
        double_waku_start = total_horses - append * 2 + 1
        waku_map = {0:0}
        for i in range(1, total_horses + 1):
            if i < double_waku_start:
                waku_map[i] = i
            else:
                waku_map[i] = double_waku_start + (i - double_waku_start) // 2
    elif total_horses <= 18:
        append = total_horses - 16
        triple_waku_start = total_horses - append * 3 + 1
        waku_map = {0:0}
        for i in range(1, total_horses + 1):
            if i < triple_waku_start:
                waku_map[i] = 1 + (i - 1) // 2
            else:
                waku_map[i] = 1 + triple_waku_start // 2 + (i - triple_waku_start) // 3
    else:
        raise ValueError("馬の総数は18頭まで対応しています。")
    return waku_map

WAKU_COLORS = {
	1: {"bg": "#ffffff", "text": "black"},
	2: {"bg": "#000000", "text": "white"},
	3: {"bg": "#ef4444", "text": "white"},
	4: {"bg": "#3b82f6", "text": "white"},
	5: {"bg": "#eab308", "text": "white"},
	6: {"bg": "#139b28", "text": "white"},
	7: {"bg": "#f97316", "text": "white"},
	8: {"bg": "#ec4899", "text": "white"},
    0: {"bg": "#9ca3af", "text": "white"},  # 仮の馬番（0番）の色
}

TRACK_IMAGE_URL_DICT = {
    "右": r"https://mujimuji666.github.io/keiba_assets/右回り.png",
    "左": r"https://mujimuji666.github.io/keiba_assets/左回り.png",
}
SURFACE_IMAGE_URL_DICT = {
    "芝": r"https://mujimuji666.github.io/keiba_assets/背景：芝.png",
    "ダート": r"https://mujimuji666.github.io/keiba_assets/背景：ダート.png",
}

SPLIT_INDEX_DICT = {
    11 : 5,
    12 : 6,
    13 : 7,
    14 : 8,
    15 : 9, # 5枠ずらしで統一するなら 9 見た目重視なら 7
    16 : 10, # 5枠ずらしで統一するなら 10 見た目重視なら 8
    17 : 10,
    18 : 10,
}


ROOT_WIDTH = 400
TOTAL_HORSE_NUM = 14


# レイアウト用定数
FORMATION_PANEL_RATIO = 400 / (400 + 84)
CONTAINER_PADDING = 10

CIRCLE_DIAMETER = 30
CIRCLE_RADIUS   = CIRCLE_DIAMETER / 2
CIRCLE_PADDING = 1

TEXT_SIZE = 12

# 画像の形式に規定される定数
ROOT_IMAGE_WIDTH  = 400 # 幅
ROOT_IMAGE_HEIGHT = 220 # 高さ
ROOT_IMAGE_CELL = ROOT_IMAGE_WIDTH * 1 / 22 # セル幅
ROOT_IMAGE_OUTER_PIXNUM = 1 # 外側の余白のセル数
ROOT_IMAGE_HEAD_PIXNUM  = 2 # 頭の余白のセル数
ROOT_IMAGE_CENTER_LINE_WIDTH = 4 # 中央線の幅
ROOT_IMAGE_SUB_LINE_WIDTH    = 2 # 補助線の幅

ROOT_FORMATION_PANEL_HEIGHT = ROOT_IMAGE_HEIGHT/2 + ROOT_IMAGE_CELL

ROOT_IMAGE_ASPECT_RATIO           = ROOT_IMAGE_HEIGHT / ROOT_IMAGE_WIDTH # 元画像縦横比
ROOT_FORMATION_PANEL_ASPECT_RATIO = ROOT_FORMATION_PANEL_HEIGHT / ROOT_IMAGE_WIDTH # パネル縦横比

ROOT_FORMATION_FRONT_PADDING = ROOT_IMAGE_CELL*(ROOT_IMAGE_OUTER_PIXNUM + ROOT_IMAGE_HEAD_PIXNUM) + CIRCLE_RADIUS + CIRCLE_PADDING
ROOT_FORMATION_BACK_PADDING  = ROOT_IMAGE_CELL*(ROOT_IMAGE_OUTER_PIXNUM)+ CIRCLE_RADIUS + CIRCLE_PADDING
ROOT_FORMATION_INNER_PADDING = ROOT_IMAGE_CELL*(ROOT_IMAGE_OUTER_PIXNUM) + CIRCLE_RADIUS + ROOT_IMAGE_CENTER_LINE_WIDTH/2 + CIRCLE_PADDING
ROOT_FORMATION_OUTER_PADDING = ROOT_IMAGE_CELL*(ROOT_IMAGE_OUTER_PIXNUM) + CIRCLE_RADIUS + ROOT_IMAGE_SUB_LINE_WIDTH/2 + CIRCLE_PADDING


class FormationHorseChip(ft.GestureDetector):
    def __init__(self, horse_number: int, calc_limit_func, waku_map, 
                 circle_diameter=CIRCLE_DIAMETER, text_size=TEXT_SIZE, **kwargs):
        
        self.calc_limit_func = calc_limit_func
        
        self.horse_number = horse_number
        self.waku_map = waku_map
        
        self.waku_number = self.waku_map[horse_number]
        
        self.text_control = ft.Text(
            str(horse_number) if horse_number != 0 else "✕", # 0番のときは「+」や「仮」にする
            size=text_size, 
            color=WAKU_COLORS[self.waku_number]["text"], 
            weight=ft.FontWeight.BOLD
        )
        
        self.default_border = ft.Border.all(2, ft.Colors.GREY_400)
        self.active_border = ft.Border.all(2, ft.Colors.BLUE)
        
        self.container = ft.Container(
            content=self.text_control,
            alignment=ft.Alignment.CENTER,
            bgcolor=WAKU_COLORS[self.waku_number]["bg"],
            border=ft.Border.all(2, ft.Colors.GREY_400),
            width=circle_diameter,
            height=circle_diameter,
            border_radius=circle_diameter // 2,
        )
        
        super().__init__(
            content=self.container, 
            on_pan_update=self.handle_drag,
            **kwargs
        )
        
    def set_horse_number(self, new_number: int):
        self.waku_number = self.waku_map[new_number] 
        self.text_control.value = str(new_number) if new_number != 0 else "✕"
        self.text_control.color = WAKU_COLORS[self.waku_number]["text"]
        self.container.bgcolor = WAKU_COLORS[self.waku_number]["bg"]
        
    def set_selected(self, selected: bool):
        if selected:
            self.container.border = self.active_border
        else:
            self.container.border = self.default_border
    
    def handle_drag(self, e: ft.Event[ft.DragUpdateEvent[ft.GestureDetector]]):
        target_delta = e.local_delta
        
        next_left = self.left + target_delta.x
        next_top = self.top + target_delta.y
        
        next_central_x = next_left + CIRCLE_DIAMETER / 2
        next_central_y = next_top + CIRCLE_DIAMETER / 2
        
        left, top = self.calc_limit_func(next_central_x, next_central_y)
        self.left = left
        self.top = top
        self.update()
        
class MenuHorseButton(ft.Container):
    def __init__(self, horse_number: int, waku_map, on_click=None, 
                 circle_diameter=CIRCLE_DIAMETER, text_size=TEXT_SIZE, **kwargs):
        
        self.horse_number = horse_number
        self.waku_map = waku_map
        
        self.waku_number = self.waku_map[horse_number]
        
        self.text_control = ft.Text(
            str(horse_number),
            size=text_size, 
            color=WAKU_COLORS[self.waku_number]["text"], 
            weight=ft.FontWeight.BOLD
        )
        
        super().__init__(
            content=self.text_control,
            alignment=ft.Alignment.CENTER,
            bgcolor=WAKU_COLORS[self.waku_number]["bg"],
            border=ft.Border.all(2, ft.Colors.GREY_400),
            width=circle_diameter,
            height=circle_diameter,
            border_radius=circle_diameter // 2,
            on_click=on_click,
            **kwargs
        )
        
    def set_enabled(self, available: bool):
        if available:
            self.opacity = 1.0
        else:
            self.opacity = 0.5
        self.update()

class FormationEditor(ft.Container):
    #-------------------------------------------------------------
    # 1. コンストラクタ
    #-------------------------------------------------------------
    def __init__(self, 
                 total_horses=TOTAL_HORSE_NUM, turn="右", surface="ダート", 
                 width = ROOT_WIDTH, 
                 **kwargs):
        
        # レース条件
        self.total_horses = total_horses
        self.turn = turn
        self.surface = surface
        self.waku_map = Generate_umaban2waku_map(total_horses)
        
        # 見た目用変数の初期化
        
        # 各コントロールのサイズ規定
        self.container_width  = width
        
        self.total_panel_width      = self.container_width - CONTAINER_PADDING * 3
        self.formation_panel_width  = self.total_panel_width * FORMATION_PANEL_RATIO
        self.select_panel_width     = self.total_panel_width * (1 - FORMATION_PANEL_RATIO)
        self.panel_height           = self.formation_panel_width * ROOT_FORMATION_PANEL_ASPECT_RATIO
        
        self.track_image_url = TRACK_IMAGE_URL_DICT[self.turn]
        self.surface_image_url = SURFACE_IMAGE_URL_DICT[self.surface]
        
        # 画像のサイズ規定
        response = requests.get(self.track_image_url)
        bg_image = Image.open(BytesIO(response.content))
        if bg_image.width != ROOT_IMAGE_WIDTH or bg_image.height != ROOT_IMAGE_HEIGHT:
            raise ValueError(f"Track image size is not as expected: {bg_image.size}")
        else:
            self.root_bg_image_width  = ROOT_IMAGE_WIDTH
            self.root_bg_image_height = ROOT_IMAGE_HEIGHT
            self.root_bg_image_aspect_ratio = ROOT_IMAGE_ASPECT_RATIO
            self.root_bg_formation_panel_height = ROOT_FORMATION_PANEL_HEIGHT
        
        self.bg_image_scale_ratio = self.formation_panel_width / self.root_bg_image_width
        
        self.bg_image_width  = self.root_bg_image_width * self.bg_image_scale_ratio
        self.bg_image_height = self.root_bg_image_height * self.bg_image_scale_ratio
        self.bg_image_slide_height = self.bg_image_height - self.panel_height
        
        self.formation_outer_padding = ROOT_FORMATION_OUTER_PADDING * self.bg_image_scale_ratio
        self.formation_inner_padding = ROOT_FORMATION_INNER_PADDING * self.bg_image_scale_ratio
        self.formation_front_padding = ROOT_FORMATION_FRONT_PADDING * self.bg_image_scale_ratio
        self.formation_back_padding  = ROOT_FORMATION_BACK_PADDING  * self.bg_image_scale_ratio
        
        self.upper_limit_dict = {
            "mukojomen": self.formation_outer_padding,
            "chokusen":  self.formation_inner_padding
        }
        
        self.under_limit_dict = {
            "mukojomen": self.panel_height - self.formation_inner_padding,
            "chokusen":  self.panel_height - self.formation_outer_padding
        }
        
        self.left_limit_dict = {
            "右": {"mukojomen": self.formation_back_padding,  "chokusen": self.formation_front_padding},
            "左": {"mukojomen": self.formation_front_padding, "chokusen": self.formation_back_padding},
        }
        self.right_limit_dict = {
            "右": {"mukojomen": self.formation_panel_width - self.formation_front_padding, 
                    "chokusen":  self.formation_panel_width - self.formation_back_padding},
            "左": {"mukojomen": self.formation_panel_width - self.formation_back_padding, 
                    "chokusen":  self.formation_panel_width - self.formation_front_padding},
        }
 
        # 状態変数の初期化
        self.active_chip = None
        self.current_mode = "mukojomen"
        
        # 馬番選択ボタン群の初期化
        self.menu_buttons_muko = self._create_menu_buttons()
        self.menu_buttons_choku = self._create_menu_buttons()
        self.menu_buttons = self.menu_buttons_muko
        
        # モード切替ボタンの初期化
        self.mode_button = ft.FilledTonalButton("向正面", on_click=self.toggle_mode, 
                                                height=45, aspect_ratio=1.0, 
                                                style=ft.ButtonStyle(padding=0, shape=ft.RoundedRectangleBorder(radius=8)))
        
        # 左パネル（馬番選択ボタン群）の初期化
        self.umaban_select_muko = self._build_umaban_select_col(self.menu_buttons_muko)
        self.umaban_select_choku = self._build_umaban_select_col(self.menu_buttons_choku)
        
        self.menu_buttons_row_container = ft.Container(
            content=self.umaban_select_muko,
            border_radius=8,
            bgcolor=ft.Colors.SURFACE_CONTAINER_LOW,
            width=self.select_panel_width, height=self.panel_height,
            padding=10,
        )
        
        # 右パネル（隊列図スタック）の初期化
        self.surface_image_layer = ft.Image(
            src=self.surface_image_url, fit=ft.BoxFit.FIT_WIDTH,
            width=self.bg_image_width, height=self.bg_image_height,
            top=0,
            )
        self.track_image_layer = ft.Image(
            src=self.track_image_url, fit=ft.BoxFit.FIT_WIDTH,
            width=self.bg_image_width, height=self.bg_image_height,
            top=0
            )
        
        print(f"bg_image_width: {self.bg_image_width}, bg_image_height: {self.bg_image_height}")
        print(f"formation_panel_width: {self.formation_panel_width}, panel_height: {self.panel_height}")
        
        self.chip_layer_muko = ft.Stack(
            width=self.formation_panel_width, height=self.formation_panel_width, top=0, visible=True)
        self.chip_layer_choku = ft.Stack(
            width=self.formation_panel_width, height=self.formation_panel_width, top=0, visible=False)
        
        self.chip_layer = self.chip_layer_muko  # アクティブなチップレイヤーを保持
        
        self.control_layer = ft.GestureDetector(on_tap_down=self.image_click)

        self.formation_area = ft.Stack(
            width=self.formation_panel_width,
            # height=self.formation_panel_width,
            controls=[
                self.surface_image_layer,
                self.track_image_layer,
                self.control_layer,
                self.chip_layer_muko,
                self.chip_layer_choku,
            ],
        )
        
        self.formation_area_container = ft.Container(
                content=self.formation_area,
                bgcolor=ft.Colors.RED,
                border_radius=8,
                # height=self.formation_panel_width, # test
            )

        editor_layout = ft.Row(
            controls=[
                self.menu_buttons_row_container, 
                self.formation_area_container,
                ],
            alignment=ft.MainAxisAlignment.CENTER, 
            vertical_alignment=ft.CrossAxisAlignment.CENTER)
        
        super().__init__(
            content=editor_layout,
            width=self.container_width, height=self.panel_height + CONTAINER_PADDING * 2,
            bgcolor=ft.Colors.SURFACE_CONTAINER_HIGHEST,
            border_radius=16,
            padding=CONTAINER_PADDING,
            **kwargs
        )
        
    # -------------------------------------------------------------
    # 2. コンストラクタ補助関数（プライベート関数）
    # -------------------------------------------------------------
    
    def _create_menu_buttons(self) -> dict[int, MenuHorseButton]:
        return {
            i: MenuHorseButton(
                horse_number=i, waku_map=self.waku_map,
                on_click=lambda e, horse_number=i: self.on_umaban_select(horse_number)
            ) for i in range(1, self.total_horses+1)
        }
           
    def _build_umaban_buttons_col_list(self, menu_buttons_dict) -> list[ft.Row]:
        if self.total_horses <= 10:
            return [ft.Column(
                controls=list(menu_buttons_dict.values()), 
                alignment=ft.MainAxisAlignment.CENTER, spacing=5)]
        else:
            split_index = SPLIT_INDEX_DICT.get(self.total_horses, self.total_horses // 2)
            return [
                ft.Column(
                    controls=list(menu_buttons_dict.values())[split_index:], 
                    alignment=ft.MainAxisAlignment.CENTER, spacing=5),
                ft.Column(
                    controls=list(menu_buttons_dict.values())[:split_index], 
                    alignment=ft.MainAxisAlignment.CENTER, spacing=5)
            ]
            
    def _build_umaban_select_col(self, menu_buttons_dict):
        umaban_buttons_col_list = self._build_umaban_buttons_col_list(menu_buttons_dict)
                
        return ft.Column(
            controls=[
                ft.Row(
                    controls=umaban_buttons_col_list,
                    alignment=ft.MainAxisAlignment.CENTER,
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                    # width=290,
                    expand=True,
                    spacing=5,
                ),
                ft.Divider(color=ft.Colors.GREY_400),
                self.mode_button
            ],
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=10,
        )
        
    # -------------------------------------------------------------
    # 3. イベント関数
    # -------------------------------------------------------------
    def toggle_mode(self, e: ft.Event[ft.Button]):
        if self.current_mode == "mukojomen":
            self.current_mode = "chokusen"
            self.menu_buttons = self.menu_buttons_choku
            self.menu_buttons_row_container.content = self.umaban_select_choku
            self.mode_button.content = "直線"
            self.surface_image_layer.top = -self.bg_image_slide_height
            self.track_image_layer.top = -self.bg_image_slide_height
            self.chip_layer_muko.visible = False
            self.chip_layer_choku.visible = True
            self.chip_layer = self.chip_layer_choku
        else:
            self.current_mode = "mukojomen"
            self.menu_buttons = self.menu_buttons_muko
            self.menu_buttons_row_container.content = self.umaban_select_muko
            self.mode_button.content = "向正面"
            self.surface_image_layer.top = 0
            self.track_image_layer.top = 0
            self.chip_layer_muko.visible = True
            self.chip_layer_choku.visible = False
            self.chip_layer = self.chip_layer_muko
        self.update()      
    
    def formation_chip_on_tap_down(self, e: ft.Event[ft.Container]):
        if self.active_chip is not None:
            self.active_chip.set_selected(False)
        self.active_chip = e.control
        self.active_chip.set_selected(True)
        self.update()
    
    def formation_chip_on_double_tap(self, e: ft.Event[ft.Container]):
        target_chip = e.control
        removed_number = target_chip.text_control.value
        if removed_number != "✕":
            self.menu_buttons[int(removed_number)].set_enabled(True)
        if target_chip == self.active_chip:
            self.active_chip = None 
        self.chip_layer.controls.remove(target_chip)
        self.update()
        
    def image_click(self, e: ft.Event[ft.TapEvent[ft.GestureDetector]]):
        clicked_position = e.local_position
        
        # print(f"Clicked position: x={clicked_position.x}, y={clicked_position.y}")  # デバッグ用出力
        
        left, top = self.calc_position_by_limit(clicked_position.x, clicked_position.y)
        
        # print(f"Calculated position: left={left}, top={top}")  # デバッグ用出力
        
        new_temp_horse = FormationHorseChip(
            horse_number=0,
            calc_limit_func=self.calc_position_by_limit,
            waku_map=self.waku_map,
            left=left, top=top,
            on_tap_down=self.formation_chip_on_tap_down,
            on_double_tap=self.formation_chip_on_double_tap
        )
        
        self.chip_layer.controls.append(new_temp_horse)

        if self.active_chip is not None:
            self.active_chip.set_selected(False)
        self.active_chip = new_temp_horse
        self.active_chip.set_selected(True)
        
    # -------------------------------------------------------------
    # 4. イベント補助関数
    # -------------------------------------------------------------
    def calc_position_by_limit(self, root_x, root_y):
        self.upper_limit = self.upper_limit_dict[self.current_mode]
        self.under_limit = self.under_limit_dict[self.current_mode]
        self.left_limit = self.left_limit_dict[self.turn][self.current_mode]
        self.right_limit = self.right_limit_dict[self.turn][self.current_mode]
        
        root_x = self.left_limit if root_x < self.left_limit else root_x if root_x < self.right_limit else self.right_limit
        root_y = self.upper_limit if root_y < self.upper_limit else root_y if root_y < self.under_limit else self.under_limit
            
        output_x = root_x - CIRCLE_DIAMETER / 2
        output_y = root_y - CIRCLE_DIAMETER / 2
        
        return output_x, output_y

    def on_umaban_select(self, horse_number: int):
        if self.active_chip is None:
            return

        old_number = self.active_chip.text_control.value
        if old_number != "✕":
            self.menu_buttons[int(old_number)].set_enabled(True)
        
        self.active_chip.set_selected(False)
        self.active_chip.set_horse_number(horse_number)

        self.menu_buttons[horse_number].set_enabled(False)

        self.update()
    

def main(page: ft.Page):
    page.title = "隊列図テスト"
    
    device_width = page.width if page.width else 400
    device_width = 400
    print(device_width)
    
    formation_editor = FormationEditor(
        turn="右", surface="ダート", total_horses=11, 
        width=device_width * 0.9
        )
    
    final_container = ft.Container(
        content=formation_editor,
        expand=True,
        alignment=ft.Alignment.CENTER,
    )
    
    page.add(final_container)
                
    
# -------------------------------------------------------------
# アプリの起動
# -------------------------------------------------------------

if __name__ == "__main__":
    ft.run(main)