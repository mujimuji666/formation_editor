import flet as ft
import datetime as dt
from behinds.data_struct import RaceID
from behinds.constants import CIRCLE_DIAMETER, TEXT_SIZE, WAKU_COLORS, CHIHO_COURSE_LIST, COURSE_DC


class FormationHorseChip(ft.GestureDetector):
    def __init__(self, horse_number: int, calc_limit_func, waku_map, 
                 circle_diameter=CIRCLE_DIAMETER, text_size=TEXT_SIZE, **kwargs):
        
        self.calc_limit_func = calc_limit_func
        
        self.horse_number = horse_number
        self.waku_map = waku_map
        
        self.waku_number = self.waku_map[horse_number]
        
        self.text_control = ft.Text(
            str(horse_number) if horse_number != 0 else "✕", # 0番のときは「+」や「仮」にする
            size=text_size, 
            color=WAKU_COLORS[self.waku_number]["text"], 
            weight=ft.FontWeight.BOLD
        )
        
        self.default_border = ft.Border.all(2, ft.Colors.GREY_400)
        self.active_border = ft.Border.all(2, ft.Colors.BLUE)
        
        self.container = ft.Container(
            content=self.text_control,
            alignment=ft.Alignment.CENTER,
            bgcolor=WAKU_COLORS[self.waku_number]["bg"],
            border=ft.Border.all(2, ft.Colors.GREY_400),
            width=circle_diameter,
            height=circle_diameter,
            border_radius=circle_diameter // 2,
        )
        
        super().__init__(
            content=self.container, 
            on_pan_update=self.handle_drag,
            **kwargs
        )
        
    def set_horse_number(self, new_number: int):
        self.waku_number = self.waku_map[new_number] 
        self.text_control.value = str(new_number) if new_number != 0 else "✕"
        self.text_control.color = WAKU_COLORS[self.waku_number]["text"]
        self.container.bgcolor = WAKU_COLORS[self.waku_number]["bg"]
        
    def set_selected(self, selected: bool):
        if selected:
            self.container.border = self.active_border
        else:
            self.container.border = self.default_border
    
    def handle_drag(self, e: ft.Event[ft.DragUpdateEvent[ft.GestureDetector]]):
        target_delta = e.local_delta
        
        next_left = self.left + target_delta.x
        next_top = self.top + target_delta.y
        
        next_central_x = next_left + CIRCLE_DIAMETER / 2
        next_central_y = next_top + CIRCLE_DIAMETER / 2
        
        left, top = self.calc_limit_func(next_central_x, next_central_y)
        self.left = left
        self.top = top
        self.update()
        
class MenuHorseButton(ft.Container):
    def __init__(self, horse_number: int, waku_map, on_click=None, 
                 circle_diameter=CIRCLE_DIAMETER, text_size=TEXT_SIZE, **kwargs):
        
        self.horse_number = horse_number
        self.waku_map = waku_map
        
        self.waku_number = self.waku_map[horse_number]
        
        self.text_control = ft.Text(
            str(horse_number),
            size=text_size, 
            color=WAKU_COLORS[self.waku_number]["text"], 
            weight=ft.FontWeight.BOLD
        )
        
        super().__init__(
            content=self.text_control,
            alignment=ft.Alignment.CENTER,
            bgcolor=WAKU_COLORS[self.waku_number]["bg"],
            border=ft.Border.all(2, ft.Colors.GREY_400),
            width=circle_diameter,
            height=circle_diameter,
            border_radius=circle_diameter // 2,
            on_click=on_click,
            **kwargs
        )
        
    def set_enabled(self, available: bool):
        if available:
            self.opacity = 1.0
        else:
            self.opacity = 0.5
        self.update()

class BlueMenuCounter(ft.PopupMenuButton):
    def __init__(self, label_suffix="回", initial_value=1, on_change_callback=None, **kwargs):
        self.value = initial_value
        self.suffix = label_suffix
        self.on_change_callback = on_change_callback

        # 表示用のテキスト
        self.text_display = ft.Text(
            f"{self.value}{self.suffix}", 
            color=ft.Colors.WHITE, 
            size=13, 
            weight=ft.FontWeight.BOLD
        )

        # ポップアップ内部の入力フィールド（高さを32pxに潰す）
        self.input_field = ft.TextField(
            value=str(self.value),
            width=50,
            height=32,
            dense=True,
            content_padding=5,
            text_size=12,
            text_align=ft.TextAlign.CENTER,
            keyboard_type=ft.KeyboardType.NUMBER,
            border=ft.Border.all(color=ft.Colors.SURFACE_CONTAINER_HIGHEST),
            on_submit=self._on_text_submit
        )

        super().__init__(
            content=ft.Row(
                [
                    self.text_display,
                    ft.Icon(ft.Icons.ARROW_DROP_DOWN, color=ft.Colors.WHITE, size=16)
                ],
                spacing=2,
                alignment=ft.MainAxisAlignment.CENTER
            ),
            # ポップアップの中身にカウンターと入力欄を同居させる
            items=[
                ft.PopupMenuItem(
                    content=ft.Row(
                        [
                            ft.IconButton(ft.Icons.REMOVE, icon_size=14, on_click=self._decrement, width=28, height=28),
                            self.input_field,
                            ft.IconButton(ft.Icons.ADD, icon_size=14, on_click=self._increment, width=28, height=28),
                        ],
                        spacing=4,
                        alignment=ft.MainAxisAlignment.CENTER,
                    )
                )
            ],
            **kwargs
        )

    def _increment(self, e):
        self.value += 1
        self._update_all()

    def _decrement(self, e):
        if self.value > 1:
            self.value -= 1
            self._update_all()

    def _on_text_submit(self, e):
        try:
            val = int(self.input_field.value)
            if val > 0:
                self.value = val
        except ValueError:
            pass
        self._update_all()

    def _update_all(self):
        self.text_display.value = f"{self.value}{self.suffix}"
        self.input_field.value = str(self.value)
        self.text_display.update()
        self.input_field.update()
        if self.on_change_callback:
            self.on_change_callback(self.value)

class RaceMenuBar(ft.Container):
    def __init__(self, race_id: RaceID, 
                 on_race_id_change=None,
                 **kwargs):
        super().__init__()
        
        # 独自保持データ
        self.race_id = race_id
        print(race_id)
        self.current_date = race_id.date
        self.current_jyo = race_id.jyo
        # self._set_race_nums(race_id.race_num)
        self.current_race_num = race_id.race_num
        self.current_kaiji = race_id.kaiji
        self.current_nichiji = race_id.nichiji
        self.on_race_id_change = on_race_id_change
        
        self.select_dates = self._set_selectable_dates()
    
        
        # 最上部の青いラインの見た目を再現
        self.bgcolor = "#2241A3"  # ネット競馬風のディープブルー
        self.height = 36          # 限界まで低く設定（36px）
        self.padding = ft.Padding.symmetric(horizontal=10)
        self.vertical_alignment = ft.CrossAxisAlignment.CENTER

        # --- パーツ1: 日付選択 ---
        self.date_text = ft.Text(self._display_date(self.current_date), color=ft.Colors.WHITE, size=13, weight=ft.FontWeight.BOLD)
        self.date_button = ft.PopupMenuButton(
            content=ft.Row(
                [
                    self.date_text,
                    ft.Icon(ft.Icons.ARROW_DROP_DOWN, color=ft.Colors.WHITE, size=16)
                ],
                spacing=2,
                alignment=ft.MainAxisAlignment.END
            ),
            items=[
                ft.PopupMenuItem(self._display_date(date), data=date, on_click=self._on_date_select) for date in self.select_dates
            ],
            width=75,
            style=ft.ButtonStyle(bgcolor=ft.Colors.RED, shape=ft.RoundedRectangleBorder(radius=0))
        )

        # --- パーツ2: 競馬場選択 ---
        self.track_text = ft.Text(self.current_jyo, color=ft.Colors.WHITE, size=13, weight=ft.FontWeight.BOLD)
        self.track_button = ft.PopupMenuButton(
            content=ft.Row(
                [
                    self.track_text,
                    ft.Icon(ft.Icons.ARROW_DROP_DOWN, color=ft.Colors.WHITE, size=16)
                ],
                spacing=2,
                alignment=ft.MainAxisAlignment.CENTER
            ),
            items=[
                ft.PopupMenuItem(content=jyo, data=jyo, on_click=self._on_jyo_select) for jyo in COURSE_DC.values() if jyo in CHIHO_COURSE_LIST or jyo in list(COURSE_DC.values())[1:11]
            ],
            width=50,
        )

        # --- パーツ3: 中央のカレンダーアイコン ---
        self.calendar_icon = ft.IconButton(
            icon=ft.Icons.CALENDAR_MONTH,
            icon_color=ft.Colors.WHITE,
            icon_size=18,
            padding=0,
            width=32,
            height=32,
            on_click=lambda e: print("DatePicker起動"),
            style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=0))
        )
        
        # --- パーツ4: 回次選択 ---
        self.kaiji_counter = BlueMenuCounter(
            label_suffix="回", initial_value=self.current_kaiji, 
            width=40,
            on_change_callback=self._on_kaiji_change)
        
        # --- パーツ5: 日次選択 ---
        self.nichiji_counter = BlueMenuCounter(
            label_suffix="日", initial_value=self.current_nichiji, 
            width=40,
            on_change_callback=self._on_nichiji_change)

        # --- パーツ6: レース切り替え ---
        self.race_text = ft.Text(f"{self.current_race_num}R", color=ft.Colors.WHITE, size=13, weight=ft.FontWeight.BOLD)
        self.race_button = ft.PopupMenuButton(
            content=ft.Row(
                [
                    self.race_text,
                    ft.Icon(ft.Icons.ARROW_DROP_DOWN, color=ft.Colors.WHITE, size=16)
                ],
                spacing=2,
                alignment=ft.MainAxisAlignment.END
            ),
            items=[
                ft.PopupMenuItem(f"{i+1}R", data=i+1, on_click=self._on_race_num_select) for i in range(12)
            ],
            width=40,
            style=ft.ButtonStyle(bgcolor=ft.Colors.RED, shape=ft.RoundedRectangleBorder(radius=0))
        )

        # # --- 1. 前のレースボタン（◀ 1R） ---
        # self.prev_race_btn = ft.Container(
        #     content=ft.Row(
        #         [
        #             ft.Icon(ft.Icons.ARROW_LEFT, color=ft.Colors.WHITE, size=16),
        #             ft.Text(f"{self.prev_race_num}R", color=ft.Colors.WHITE, size=13, weight=ft.FontWeight.BOLD),
        #         ],
        #         spacing=2,
        #         alignment=ft.MainAxisAlignment.CENTER
        #     ),
        #     on_click=self._on_prev_race_click,
        #     height=32,
        #     width=36
        # )

        # # --- 2. 次のレースボタン（3R ▶） ---
        # self.next_race_btn = ft.Container(
        #     content=ft.Row(
        #         [
        #             ft.Text(f"{self.next_race_num}R", color=ft.Colors.WHITE, size=13, weight=ft.FontWeight.BOLD),
        #             ft.Icon(ft.Icons.ARROW_RIGHT, color=ft.Colors.WHITE, size=16)
        #         ],
        #         spacing=2,
        #         alignment=ft.MainAxisAlignment.CENTER
        #     ),
        #     on_click=self._on_next_race_click,
        #     height=32,
        #     width=36
        # )
        
        # --- パーツ7: レースID表示 ---
        self.race_id_text = ft.Text(self.race_id.race_id, color=ft.Colors.WHITE, size=13, weight=ft.FontWeight.BOLD, text_align=ft.TextAlign.END)

        # 横一列に美しく整列
        self.content = ft.Row(
            controls=[
                self.date_button,
                ft.VerticalDivider(color=ft.Colors.WHITE_24, width=1, thickness=1), # 縦の区切り線
                self.track_button,
                ft.VerticalDivider(color=ft.Colors.WHITE_24, width=1, thickness=1),
                self.calendar_icon,
                ft.VerticalDivider(color=ft.Colors.WHITE_24, width=1, thickness=1),
                self.kaiji_counter,
                ft.VerticalDivider(color=ft.Colors.WHITE_24, width=1, thickness=1),
                self.nichiji_counter,
                ft.VerticalDivider(color=ft.Colors.WHITE_24, width=1, thickness=1),
                self.race_button,
                ft.VerticalDivider(color=ft.Colors.WHITE_24, width=1, thickness=1),
                ft.Container(expand=True),
                self.race_id_text,
            ],
            alignment=ft.MainAxisAlignment.START,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=10,
            **kwargs
        )
        
    # イベント関数
    def _on_date_select(self, e: ft.Event[ft.PopupMenuItem]):
        self.current_date = e.control.data
        self.date_button.content.controls[0].value = self._display_date(self.current_date)
        self.date_button.content.update()
        self._reset_race_id()
        print(f"日付が選択されました: {self.current_date}")
    
    def _on_jyo_select(self, e: ft.Event[ft.PopupMenuItem]):
        self.current_jyo = e.control.data
        self.track_text.value = self.current_jyo
        self._reset_race_id()
        self.track_text.update()
        print(f"競馬場が選択されました: {self.current_jyo}")
        
    def _on_kaiji_change(self, new_value: int):
        ''' 回次が変更されたときの処理 '''
        self.current_kaiji = new_value
        self._reset_race_id()
        print(f"回次が変更されました: {self.current_kaiji}回")
        
    def _on_nichiji_change(self, new_value: int):
        ''' 日次が変更されたときの処理 '''
        self.current_nichiji = new_value
        self._reset_race_id()
        print(f"日次が変更されました: {self.current_nichiji}日")
        
    def _on_race_num_select(self, e: ft.Event[ft.PopupMenuItem]):
        self.current_race_num = e.control.data
        self.race_text.value = f"{self.current_race_num}R"
        self.race_text.update()
        self._reset_race_id()
        print(f"レース番号が選択されました: {self.current_race_num}R")
    
    
    # 独自関数
    # def _set_race_nums(self, race_num: int):
    #     self.current_race_num = race_num
    #     self.prev_race_num = self.current_race_num - 1
    #     self.next_race_num = self.current_race_num + 1
    #     if not hasattr(self, 'prev_race_btn') or not hasattr(self, 'next_race_btn'):
    #         return
    #     self.prev_race_btn.content.controls[1].value = f"{self.prev_race_num}R"
    #     self.prev_race_btn.content.update()
    #     self.next_race_btn.content.controls[0].value = f"{self.next_race_num}R"
    #     self.next_race_btn.content.update()
    
    def _reset_race_id(self):
        ''' 現在のレースIDを取得 '''
        self.race_id = RaceID(
            self.current_date, 
            self.current_jyo, 
            self.current_kaiji, 
            self.current_nichiji, 
            self.current_race_num
        )
        
        if hasattr(self, 'race_id_text'):
            self.race_id_text.value = self.race_id.race_id
            self.race_id_text.update()
        
        if self.on_race_id_change:
            self.on_race_id_change(self.race_id)
            
    def _set_selectable_dates(self):
        for i in range(7):
            date = self.current_date - dt.timedelta(days=i)
            if date.weekday() == 5:
                first_saturday = date
                break
        return [first_saturday + dt.timedelta(days=i) for i in range(7)]
    
    def _display_date(self, date: dt.date) -> str:
        weekday_map = ["月", "火", "水", "木", "金", "土", "日"]
        return f"{date.month}/{date.day}({weekday_map[date.weekday()]})"