import datetime as dt
from .constants import YOUBI_CARACTER_LIST, COURSE_DC

class RaceID:
    def __init__(self, date:dt.date, jyo:str, kaiji:int, nichiji:int, race_num:int):
        self.date = date
        self.jyo = jyo
        self.kaiji = kaiji
        self.nichiji = nichiji
        self.race_num = race_num
        self.youbi = YOUBI_CARACTER_LIST[self.date.weekday()]
        self.race_id = self._calc_race_id()
        
    # 内部メソッド
    def _calc_race_id(self):
        """レースIDを計算する"""
        date_str = self.date.strftime("%Y%m%d")
        jyo_code = {v: k for k, v in COURSE_DC.items()}.get(self.jyo, "00")
        kaiji_str = str(self.kaiji).zfill(2)
        nichiji_str = str(self.nichiji).zfill(2)
        race_num_str = str(self.race_num).zfill(2)
        
        race_id = f"{date_str}{jyo_code}{kaiji_str}{nichiji_str}{race_num_str}"
        return race_id
    
    # 外部メソッド
    def display_date(self, date: dt.date) -> str:
        '''日付を「月/日(曜)」の形式で表示する'''
        return f"{self.date.month}/{self.date.day}({self.youbi})"
    
def parse_race_id(race_id: str) -> RaceID:
    """レースIDを解析して RaceID オブジェクトを返す"""
    date_str = race_id[:8]
    jyo_code = race_id[8:10]
    kaiji_str = race_id[10:12]
    nichiji_str = race_id[12:14]
    race_num_str = race_id[14:16]

    date = dt.datetime.strptime(date_str, "%Y%m%d").date()
    jyo = COURSE_DC.get(jyo_code, "_")
    kaiji = int(kaiji_str)
    nichiji = int(nichiji_str)
    race_num = int(race_num_str)

    return RaceID(date, jyo, kaiji, nichiji, race_num)
    
