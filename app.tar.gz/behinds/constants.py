YOUBI_CARACTER_LIST = ["月", "火", "水", "木", "金", "土", "日"]

CHIHO_COURSE_LIST = ["門別", "盛岡", "水沢", "浦和", "船橋", "大井", "川崎", "金沢", "笠松", "名古屋", "園田", "姫路", "高知", "佐賀"]

COURSE_DC = {
'00': "_",
'01': '札幌',
'02': '函館',
'03': '福島',
'04': '新潟',
'05': '東京',
'06': '中山',
'07': '中京',
'08': '京都',
'09': '阪神',
'10': '小倉',
'30': '門別',
'31': '北見',
'32': '岩見',
'33': '帯広',
'34': '旭川',
'35': '盛岡',
'36': '水沢',
'37': '上山',
'38': '三条',
'39': '足利',
'40': '宇都',
'41': '高崎',
'42': '浦和',
'43': '船橋',
'44': '大井',
'45': '川崎',
'46': '金沢',
'47': '笠松',
'48': '名古',
'49': '紀三',
'50': '園田',
'51': '姫路',
'52': '益田',
'53': '福山',
'54': '高知',
'55': '佐賀',
'56': '荒尾',
'57': '中津',
'58': '札幌(地方)',
'59': '函館(地方)',
'60': '新潟(地方)',
'61': '中京(地方)',
'A0': '他外',
'A2': '日本',
'A4': 'アメ',
'A6': 'イギ',
'A8': 'フラ',
'B0': 'イン',
'B2': 'アイ',
'B4': 'ニュ',
'B6': 'オー',
'B8': 'カナ',
'C0': 'イタ',
'C2': 'ドイ',
'C4': '',
'C5': 'オマ',
'C6': 'イラ',
'C7': 'ア首',
'C8': 'シリ',
'D0': 'スウ',
'D2': 'ハン',
'D4': 'ポル',
'D6': 'ロシ',
'D8': 'ウル',
'E0': 'ペル',
'E2': 'アル',
'E4': 'ブラ',
'E6': 'ベル',
'E8': 'トル',
'F0': '韓国',
'F1': '中国',
'F2': 'チリ',
'F4': '',
'F6': '',
'F8': 'パナ',
'G0': '香港',
'G2': 'スペ',
'G4': '',
'G6': '',
'G8': '',
'H0': '西独',
'H2': '南ア',
'H4': 'スイ',
'H6': 'モナ',
'H8': 'フィ',
'I0': 'プエ',
'I2': 'コロ',
'I4': 'チェ',
'I6': 'チェ',
'I8': 'スロ',
'J0': 'エク',
'J2': 'ギリ',
'J4': 'マレ',
'J6': 'メキ',
'J8': 'モロ',
'K0': 'パキ',
'K2': 'ポー',
'K4': 'パラ',
'K6': 'サウ',
'K8': 'キプ',
'L0': 'タイ',
'L2': 'ウク',
'L4': 'ベネ',
'L6': 'ユー',
'L8': 'デン',
'M0': 'シン',
'M2': '澳門',
'M4': '墺',
'M6': '約',
'M8': '華',
'N0': '東独',
'N2': '巴林',}

WAKU_COLORS = {
	1: {"bg": "#ffffff", "text": "black"},
	2: {"bg": "#000000", "text": "white"},
	3: {"bg": "#ef4444", "text": "white"},
	4: {"bg": "#3b82f6", "text": "white"},
	5: {"bg": "#fdc51e", "text": "white"},
	6: {"bg": "#139b28", "text": "white"},
	7: {"bg": "#f97316", "text": "white"},
	8: {"bg": "#ec4899", "text": "white"},
    0: {"bg": "#9ca3af", "text": "white"},  # 仮の馬番（0番）の色
}

TRACK_IMAGE_URL_DICT = {
    "右": r"https://mujimuji666.github.io/keiba_assets/右回り.png",
    "左": r"https://mujimuji666.github.io/keiba_assets/左回り.png",
}
SURFACE_IMAGE_URL_DICT = {
    "芝": r"https://mujimuji666.github.io/keiba_assets/背景：芝.png",
    "ダート": r"https://mujimuji666.github.io/keiba_assets/背景：ダート.png",
}

SPLIT_INDEX_DICT = {
    6 : 4,
    7 : 4,
    8 : 4,
    9 : 5,
    10 : 5,
    11 : 5,
    12 : 6,
    13 : 7,
    14 : 8,
    15 : 9, # 5枠ずらしで統一するなら 9 見た目重視なら 7
    16 : 10, # 5枠ずらしで統一するなら 10 見た目重視なら 8
    17 : 10,
    18 : 10,
}
MIN_SPLIT_INDEX = 6

ROOT_HEIGHT = 300
TOTAL_HORSE_NUM = 14

# レイアウト用定数
FORMATION_PANEL_RATIO = 500 / 85
CONTAINER_PADDING = 10

CIRCLE_DIAMETER = 30
CIRCLE_RADIUS   = CIRCLE_DIAMETER / 2
CIRCLE_PADDING = 1

TEXT_SIZE = 14

# 画像の形式に規定される定数
ROOT_IMAGE_WIDTH  = 400 # 幅
ROOT_IMAGE_HEIGHT = 220 # 高さ
ROOT_IMAGE_CELL = ROOT_IMAGE_HEIGHT * 1 / 22 # セル幅
ROOT_IMAGE_OUTER_PIXNUM = 1 # 外側の余白のセル数
ROOT_IMAGE_HEAD_PIXNUM  = 2 # 頭の余白のセル数
ROOT_IMAGE_CENTER_LINE_WIDTH = 4 # 中央線の幅
ROOT_IMAGE_SUB_LINE_WIDTH    = 2 # 補助線の幅

ROOT_FORMATION_PANEL_HEIGHT = ROOT_IMAGE_HEIGHT/2 + ROOT_IMAGE_CELL

ROOT_SELECT_PANEL_ASPECT_RATIO    = 85 / 300 # 選択パネル縦横比
ROOT_IMAGE_ASPECT_RATIO           = ROOT_IMAGE_HEIGHT / ROOT_IMAGE_WIDTH # 元画像縦横比
ROOT_FORMATION_PANEL_ASPECT_RATIO = ROOT_FORMATION_PANEL_HEIGHT / ROOT_IMAGE_WIDTH # 隊列パネル縦横比

ROOT_FORMATION_FRONT_PADDING = ROOT_IMAGE_CELL*(ROOT_IMAGE_OUTER_PIXNUM + ROOT_IMAGE_HEAD_PIXNUM)
ROOT_FORMATION_BACK_PADDING  = ROOT_IMAGE_CELL*(ROOT_IMAGE_OUTER_PIXNUM)
ROOT_FORMATION_INNER_PADDING = ROOT_IMAGE_CELL*(ROOT_IMAGE_OUTER_PIXNUM) + ROOT_IMAGE_CENTER_LINE_WIDTH/2
ROOT_FORMATION_OUTER_PADDING = ROOT_IMAGE_CELL*(ROOT_IMAGE_OUTER_PIXNUM) + ROOT_IMAGE_SUB_LINE_WIDTH/2