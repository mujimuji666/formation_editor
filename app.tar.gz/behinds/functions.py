def Generate_umaban2waku_map(total_horses: int) -> dict[int, int]:
    """馬番から枠番へのマッピングを生成する"""
    if total_horses <= 8:
        waku_map = {i: i for i in range(0, total_horses + 1)}
    elif total_horses <= 16:
        append = total_horses - 8
        double_waku_start = total_horses - append * 2 + 1
        waku_map = {0:0}
        for i in range(1, total_horses + 1):
            if i < double_waku_start:
                waku_map[i] = i
            else:
                waku_map[i] = double_waku_start + (i - double_waku_start) // 2
    elif total_horses <= 18:
        append = total_horses - 16
        triple_waku_start = total_horses - append * 3 + 1
        waku_map = {0:0}
        for i in range(1, total_horses + 1):
            if i < triple_waku_start:
                waku_map[i] = 1 + (i - 1) // 2
            else:
                waku_map[i] = 1 + triple_waku_start // 2 + (i - triple_waku_start) // 3
    else:
        raise ValueError("馬の総数は18頭まで対応しています。")
    return waku_map

