import flet as ft

WAKU_COLORS = {
	'1': {"bg": "#ffffff", "text": "black"},
	'2': {"bg": "#000000", "text": "white"},
	'3': {"bg": "#ef4444", "text": "white"},
	'4': {"bg": "#3b82f6", "text": "white"},
	'5': {"bg": "#eab308", "text": "white"},
	'6': {"bg": "#139b28", "text": "white"},
	'7': {"bg": "#f97316", "text": "white"},
	'8': {"bg": "#ec4899", "text": "white"},
    '0': {"bg": "#9ca3af", "text": "white"},  # 仮の馬番（0番）の色
}

CIRCLE_DIAMETER = 23
TEXT_SIZE = 12
TOTAL_HORSE_NUM = 8

mukojomen_upper_limit = 28
mukojomen_under_limit = 100

center_line = 115

chokusen_upper_limit = 130
chokusen_under_limit = 202

left_limit = 35
right_limit = 365

class FormationHorseChip(ft.GestureDetector):
    def __init__(self, horse_number: int, calc_limit_func, 
                 circle_diameter=CIRCLE_DIAMETER, text_size=TEXT_SIZE, **kwargs):
        
        self.calc_limit_func = calc_limit_func
        
        self.text_control = ft.Text(
            str(horse_number) if horse_number != 0 else "✕", # 0番のときは「+」や「仮」にする
            size=text_size, 
            color=WAKU_COLORS[str(horse_number)]["text"], 
            weight=ft.FontWeight.BOLD
        )
        
        self.default_border = ft.Border.all(2, ft.Colors.GREY_400)
        self.active_border = ft.Border.all(2, ft.Colors.BLUE)
        
        self.container = ft.Container(
            content=self.text_control,
            alignment=ft.Alignment.TOP_CENTER,
            bgcolor=WAKU_COLORS[str(horse_number)]["bg"],
            border=ft.Border.all(2, ft.Colors.GREY_400),
            width=circle_diameter,
            height=circle_diameter,
            border_radius=circle_diameter // 2,
        )
        
        super().__init__(
            content=self.container, 
            on_pan_update=self.handle_drag,
            **kwargs
        )
        
    def set_horse_number(self, new_number: int):
        self.text_control.value = str(new_number) if new_number != 0 else "✕"
        self.text_control.color = WAKU_COLORS[str(new_number)]["text"]
        self.container.bgcolor = WAKU_COLORS[str(new_number)]["bg"]
        
    def set_selected(self, selected: bool):
        if selected:
            self.container.border = self.active_border
        else:
            self.container.border = self.default_border
    
    def handle_drag(self, e: ft.Event[ft.DragUpdateEvent[ft.GestureDetector]]):
        target_delta = e.local_delta
        
        next_left = self.left + target_delta.x
        next_top = self.top + target_delta.y
        
        next_central_x = next_left + CIRCLE_DIAMETER / 2
        next_central_y = next_top + CIRCLE_DIAMETER / 2
        
        left, top = self.calc_limit_func(next_central_x, next_central_y)
        self.left = left
        self.top = top
        
class MenuHorseButton(ft.Container):
    def __init__(self, horse_number: int, on_click=None, 
                 circle_diameter=CIRCLE_DIAMETER, text_size=TEXT_SIZE, **kwargs):
        self.horse_number = horse_number
        
        self.text_control = ft.Text(
            str(horse_number),
            size=text_size, 
            color=WAKU_COLORS[str(horse_number)]["text"], 
            weight=ft.FontWeight.BOLD
        )
        
        super().__init__(
            content=self.text_control,
            alignment=ft.Alignment.TOP_CENTER,
            bgcolor=WAKU_COLORS[str(horse_number)]["bg"],
            border=ft.Border.all(2, ft.Colors.GREY_400),
            width=circle_diameter,
            height=circle_diameter,
            border_radius=circle_diameter // 2,
            on_click=on_click,
            **kwargs
        )
        
    def set_enabled(self, available: bool):
        if available:
            self.opacity = 1.0
        else:
            self.opacity = 0.5
        self.update()

def main(page: ft.Page):
    page.title = "隊列図テスト"
    
    # -------------------------------------------------------------
    # 1. 状態変数・パーツの定義
    # -------------------------------------------------------------
    active_chip = None
    current_mode = "mukojomen"
    
    center_mergin = 3
    muko_mask = ft.Container(
        bgcolor="#40000000", # 黒の半透明
        width=400, height=center_line-center_mergin, # 向こう正面エリアのサイズ
        left=0, top=0,
        visible=False # 最初は向こう正面モードなので、暗くしない（非表示）
    )
    choku_mask = ft.Container(
        bgcolor="#40000000",
        width=400, height=250 - center_line-center_mergin, # 直線エリアのサイズ
        left=0, top=center_line+center_mergin,
        visible=True # 最初は直線側を暗くしておく（表示）
    )
    
    #-------------------------------------------------------------
    # 2. モード切替システム
    #-------------------------------------------------------------
    def toggle_mode(e: ft.Event[ft.Button]):
        nonlocal current_mode, menu_buttons
        
        if current_mode == "mukojomen":
            current_mode = "chokusen"
            menu_buttons = menu_buttons_choku
            muko_mask.visible = True
            choku_mask.visible = False
            umaban_select_wrapper.content = umaban_select_choku
            mode_button.text = "モード：直線"
        else:
            current_mode = "mukojomen"
            menu_buttons = menu_buttons_muko
            muko_mask.visible = False
            choku_mask.visible = True
            umaban_select_wrapper.content = umaban_select_muko
            mode_button.text = "モード：向こう正面"
                
    mode_button = ft.FilledTonalButton("モード：向こう正面", on_click=toggle_mode)
    
    # -------------------------------------------------------------
    # 3. 移動範囲の制限関数
    # -------------------------------------------------------------
    def calc_position_by_limit(root_x, root_y):
        global mukojomen_upper_limit, mukojomen_under_limit, chokusen_upper_limit, chokusen_under_limit, left_limit, right_limit
        root_x = left_limit if root_x < left_limit else root_x if root_x < right_limit else right_limit
        if current_mode == "mukojomen":
            root_y = mukojomen_upper_limit if root_y < mukojomen_upper_limit else root_y if root_y < mukojomen_under_limit else mukojomen_under_limit
        else:
            root_y = chokusen_upper_limit if root_y < chokusen_upper_limit else root_y if root_y < chokusen_under_limit else chokusen_under_limit
        output_x = root_x - CIRCLE_DIAMETER / 2
        output_y = root_y - CIRCLE_DIAMETER / 2
        return output_x, output_y
    
    # -------------------------------------------------------------
    # 4. FormatinHorseChip のイベント関数
    # -------------------------------------------------------------
    def formation_chip_on_tap(e: ft.Event[ft.Container]):
        nonlocal active_chip
        if active_chip is not None:
            active_chip.set_selected(False)
        active_chip = e.control
        active_chip.set_selected(True)
        page.update()
    
    def formation_chip_on_double_tap(e: ft.Event[ft.Container]):
        nonlocal active_chip
        target_chip = e.control
        removed_number = target_chip.text_control.value
        if removed_number != "✕":
            menu_buttons[int(removed_number)].set_enabled(True)
        if target_chip == active_chip:
            active_chip = None 
        chip_layer.controls.remove(target_chip)
        page.update()
        
    # -------------------------------------------------------------
    # 5. 背景クリック時のイベント関数
    # -------------------------------------------------------------
    def image_click(e: ft.EventHandler[ft.TapEvent[ft.GestureDetector]]):
        nonlocal active_chip
        clicked_position = e.local_position
        
        if current_mode == "mukojomen" and clicked_position.y > center_line:
            return
        if current_mode == "chokusen" and clicked_position.y <= center_line:
            return
        
        left, top = calc_position_by_limit(clicked_position.x, clicked_position.y)
        
        new_temp_horse = FormationHorseChip(
            horse_number=0,
            calc_limit_func=calc_position_by_limit,
            left=left, top=top,
            on_tap=formation_chip_on_tap,
            on_secondary_tap=formation_chip_on_double_tap
        )
        
        print(f"Clicked at: ({clicked_position.x}, {clicked_position.y})") # for debugging
        chip_layer.controls.append(new_temp_horse)
        
        if active_chip is not None:
            active_chip.set_selected(False)
        active_chip = new_temp_horse
        active_chip.set_selected(True)
        
    def image_scroll(e: ft.Event[ft.ScrollEvent[ft.GestureDetector]]):
        if e.scroll_delta.y < 0:
            print(f"Scrolled up: {e.scroll_delta}")
        elif e.scroll_delta.y > 0:
            print(f"Scrolled down: {e.scroll_delta}")
        
    # -------------------------------------------------------------
    # 6. 馬番選択ボタンのイベント関数
    # -------------------------------------------------------------
    def on_umaban_select(horse_number: int):
        nonlocal active_chip
        
        if active_chip is None:
            return
        
        old_number = active_chip.text_control.value
        if old_number != "✕":
            menu_buttons[int(old_number)].set_enabled(True)
        
        active_chip.set_selected(False)
        active_chip.set_horse_number(horse_number)
        
        menu_buttons[horse_number].set_enabled(False)
        
        page.update()
        
    # -------------------------------------------------------------
    # 7. 左パネル（隊列図スタック）の初期化
    # -------------------------------------------------------------
    bg_image_layer = ft.Image(
        src=r"C:\Users\mozuk\Documents\競馬\素材\隊列図\右回り.png",fit=ft.BoxFit.CONTAIN, width=400, height=230
        )
    chip_layer = ft.Stack(width=400, height=250)
    control_layer = ft.GestureDetector(on_tap_down=image_click, on_scroll=image_scroll, width=400, height=250)
    
    formation_area = ft.Stack(
        width=400,
        height=250,
        controls=[
            bg_image_layer,
            control_layer,
            chip_layer,
            muko_mask,
            choku_mask,
        ]
    )
    
    # -------------------------------------------------------------
    # 8. 右パネル（馬番選択ボタン群）の初期化
    # -------------------------------------------------------------
    menu_buttons_muko = {
            i: MenuHorseButton(
                horse_number=i,
                on_click=lambda e, horse_number=i: on_umaban_select(horse_number)
            ) for i in range(1, TOTAL_HORSE_NUM+1)
        }
    menu_buttons_choku = {
            i: MenuHorseButton(
                horse_number=i,
                on_click=lambda e, horse_number=i: on_umaban_select(horse_number)
            ) for i in range(1, TOTAL_HORSE_NUM+1)
        }
    menu_buttons = menu_buttons_muko
    
    umaban_select_muko = ft.Column(
        controls=list(menu_buttons_muko.values()),
        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
    )
    
    umaban_select_choku = ft.Column(
        controls=list(menu_buttons_choku.values()),
        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
    )
    
    umaban_select_wrapper = ft.Container(
            content=umaban_select_muko,
            width=100,
            height=250,
            bgcolor=ft.Colors.SURFACE_CONTAINER_LOW,
            border_radius=8,
            padding=5,
        )
    
    # -------------------------------------------------------------
    # 9. コントロールの配置
    # -------------------------------------------------------------
    page.add(
        ft.Column(
            controls=[
                mode_button,
                ft.Container(
                    ft.Row(controls=[formation_area, umaban_select_wrapper], spacing=20, 
                        alignment=ft.MainAxisAlignment.CENTER, vertical_alignment=ft.CrossAxisAlignment.CENTER),
                    bgcolor=ft.Colors.SURFACE_CONTAINER_HIGHEST,
                    border_radius=8,
                    width=650,
                    height=300,
                    padding=10,
                )
            ]
        )
    )
    
    
# -------------------------------------------------------------
# アプリの起動
# -------------------------------------------------------------
ft.run(main)