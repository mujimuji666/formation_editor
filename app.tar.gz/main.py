import flet as ft
import datetime as dt

# constants.py
YOUBI_CARACTER_LIST = ["月", "火", "水", "木", "金", "土", "日"]

CHIHO_COURSE_LIST = ["門別", "盛岡", "水沢", "浦和", "船橋", "大井", "川崎", "金沢", "笠松", "名古屋", "園田", "姫路", "高知", "佐賀"]

COURSE_DC = {
'00': "_",
'01': '札幌',
'02': '函館',
'03': '福島',
'04': '新潟',
'05': '東京',
'06': '中山',
'07': '中京',
'08': '京都',
'09': '阪神',
'10': '小倉',
'30': '門別',
'31': '北見',
'32': '岩見',
'33': '帯広',
'34': '旭川',
'35': '盛岡',
'36': '水沢',
'37': '上山',
'38': '三条',
'39': '足利',
'40': '宇都',
'41': '高崎',
'42': '浦和',
'43': '船橋',
'44': '大井',
'45': '川崎',
'46': '金沢',
'47': '笠松',
'48': '名古',
'49': '紀三',
'50': '園田',
'51': '姫路',
'52': '益田',
'53': '福山',
'54': '高知',
'55': '佐賀',
'56': '荒尾',
'57': '中津',
'58': '札幌(地方)',
'59': '函館(地方)',
'60': '新潟(地方)',
'61': '中京(地方)',
'A0': '他外',
'A2': '日本',
'A4': 'アメ',
'A6': 'イギ',
'A8': 'フラ',
'B0': 'イン',
'B2': 'アイ',
'B4': 'ニュ',
'B6': 'オー',
'B8': 'カナ',
'C0': 'イタ',
'C2': 'ドイ',
'C4': '',
'C5': 'オマ',
'C6': 'イラ',
'C7': 'ア首',
'C8': 'シリ',
'D0': 'スウ',
'D2': 'ハン',
'D4': 'ポル',
'D6': 'ロシ',
'D8': 'ウル',
'E0': 'ペル',
'E2': 'アル',
'E4': 'ブラ',
'E6': 'ベル',
'E8': 'トル',
'F0': '韓国',
'F1': '中国',
'F2': 'チリ',
'F4': '',
'F6': '',
'F8': 'パナ',
'G0': '香港',
'G2': 'スペ',
'G4': '',
'G6': '',
'G8': '',
'H0': '西独',
'H2': '南ア',
'H4': 'スイ',
'H6': 'モナ',
'H8': 'フィ',
'I0': 'プエ',
'I2': 'コロ',
'I4': 'チェ',
'I6': 'チェ',
'I8': 'スロ',
'J0': 'エク',
'J2': 'ギリ',
'J4': 'マレ',
'J6': 'メキ',
'J8': 'モロ',
'K0': 'パキ',
'K2': 'ポー',
'K4': 'パラ',
'K6': 'サウ',
'K8': 'キプ',
'L0': 'タイ',
'L2': 'ウク',
'L4': 'ベネ',
'L6': 'ユー',
'L8': 'デン',
'M0': 'シン',
'M2': '澳門',
'M4': '墺',
'M6': '約',
'M8': '華',
'N0': '東独',
'N2': '巴林',}

WAKU_COLORS = {
	1: {"bg": "#ffffff", "text": "black"},
	2: {"bg": "#000000", "text": "white"},
	3: {"bg": "#ef4444", "text": "white"},
	4: {"bg": "#3b82f6", "text": "white"},
	5: {"bg": "#fdc51e", "text": "white"},
	6: {"bg": "#139b28", "text": "white"},
	7: {"bg": "#f97316", "text": "white"},
	8: {"bg": "#ec4899", "text": "white"},
    0: {"bg": "#9ca3af", "text": "white"},  # 仮の馬番（0番）の色
}

TRACK_IMAGE_URL_DICT = {
    "右": r"https://mujimuji666.github.io/keiba_assets/右回り.png",
    "左": r"https://mujimuji666.github.io/keiba_assets/左回り.png",
}
SURFACE_IMAGE_URL_DICT = {
    "芝": r"https://mujimuji666.github.io/keiba_assets/背景：芝.png",
    "ダート": r"https://mujimuji666.github.io/keiba_assets/背景：ダート.png",
}

SPLIT_INDEX_DICT = {
    6 : 4,
    7 : 4,
    8 : 4,
    9 : 5,
    10 : 5,
    11 : 5,
    12 : 6,
    13 : 7,
    14 : 8,
    15 : 9, # 5枠ずらしで統一するなら 9 見た目重視なら 7
    16 : 10, # 5枠ずらしで統一するなら 10 見た目重視なら 8
    17 : 10,
    18 : 10,
}
MIN_SPLIT_INDEX = 6

ROOT_HEIGHT = 300
TOTAL_HORSE_NUM = 14

# レイアウト用定数
FORMATION_PANEL_RATIO = 500 / 85
CONTAINER_PADDING = 10

CIRCLE_DIAMETER = 30
CIRCLE_RADIUS   = CIRCLE_DIAMETER / 2
CIRCLE_PADDING = 1

TEXT_SIZE = 14

# 画像の形式に規定される定数
ROOT_IMAGE_WIDTH  = 400 # 幅
ROOT_IMAGE_HEIGHT = 220 # 高さ
ROOT_IMAGE_CELL = ROOT_IMAGE_HEIGHT * 1 / 22 # セル幅
ROOT_IMAGE_OUTER_PIXNUM = 1 # 外側の余白のセル数
ROOT_IMAGE_HEAD_PIXNUM  = 2 # 頭の余白のセル数
ROOT_IMAGE_CENTER_LINE_WIDTH = 4 # 中央線の幅
ROOT_IMAGE_SUB_LINE_WIDTH    = 2 # 補助線の幅

ROOT_FORMATION_PANEL_HEIGHT = ROOT_IMAGE_HEIGHT/2 + ROOT_IMAGE_CELL

ROOT_SELECT_PANEL_ASPECT_RATIO    = 85 / 300 # 選択パネル縦横比
ROOT_IMAGE_ASPECT_RATIO           = ROOT_IMAGE_HEIGHT / ROOT_IMAGE_WIDTH # 元画像縦横比
ROOT_FORMATION_PANEL_ASPECT_RATIO = ROOT_FORMATION_PANEL_HEIGHT / ROOT_IMAGE_WIDTH # 隊列パネル縦横比

ROOT_FORMATION_FRONT_PADDING = ROOT_IMAGE_CELL*(ROOT_IMAGE_OUTER_PIXNUM + ROOT_IMAGE_HEAD_PIXNUM)
ROOT_FORMATION_BACK_PADDING  = ROOT_IMAGE_CELL*(ROOT_IMAGE_OUTER_PIXNUM)
ROOT_FORMATION_INNER_PADDING = ROOT_IMAGE_CELL*(ROOT_IMAGE_OUTER_PIXNUM) + ROOT_IMAGE_CENTER_LINE_WIDTH/2
ROOT_FORMATION_OUTER_PADDING = ROOT_IMAGE_CELL*(ROOT_IMAGE_OUTER_PIXNUM) + ROOT_IMAGE_SUB_LINE_WIDTH/2

# data_struct.py
class RaceID:
    def __init__(self, date:dt.date, jyo:str, kaiji:int, nichiji:int, race_num:int):
        self.date = date
        self.jyo = jyo
        self.kaiji = kaiji
        self.nichiji = nichiji
        self.race_num = race_num
        self.youbi = YOUBI_CARACTER_LIST[self.date.weekday()]
        self.race_id = self._calc_race_id()
        
    # 内部メソッド
    def _calc_race_id(self):
        """レースIDを計算する"""
        date_str = self.date.strftime("%Y%m%d")
        jyo_code = {v: k for k, v in COURSE_DC.items()}.get(self.jyo, "00")
        kaiji_str = str(self.kaiji).zfill(2)
        nichiji_str = str(self.nichiji).zfill(2)
        race_num_str = str(self.race_num).zfill(2)
        
        race_id = f"{date_str}{jyo_code}{kaiji_str}{nichiji_str}{race_num_str}"
        return race_id
    
    # 外部メソッド
    def display_date(self, date: dt.date) -> str:
        '''日付を「月/日(曜)」の形式で表示する'''
        return f"{self.date.month}/{self.date.day}({self.youbi})"
    
def parse_race_id(race_id: str) -> RaceID:
    """レースIDを解析して RaceID オブジェクトを返す"""
    date_str = race_id[:8]
    jyo_code = race_id[8:10]
    kaiji_str = race_id[10:12]
    nichiji_str = race_id[12:14]
    race_num_str = race_id[14:16]

    date = dt.datetime.strptime(date_str, "%Y%m%d").date()
    jyo = COURSE_DC.get(jyo_code, "_")
    kaiji = int(kaiji_str)
    nichiji = int(nichiji_str)
    race_num = int(race_num_str)

    return RaceID(date, jyo, kaiji, nichiji, race_num)
    
# parts.py
class FormationHorseChip(ft.GestureDetector):
    def __init__(self, horse_number: int, calc_limit_func, waku_map, 
                 circle_diameter=CIRCLE_DIAMETER, text_size=TEXT_SIZE, **kwargs):
        
        self.calc_limit_func = calc_limit_func
        
        self.horse_number = horse_number
        self.waku_map = waku_map
        
        self.waku_number = self.waku_map[horse_number]
        
        self.text_control = ft.Text(
            str(horse_number) if horse_number != 0 else "✕", # 0番のときは「+」や「仮」にする
            size=text_size, 
            color=WAKU_COLORS[self.waku_number]["text"], 
            weight=ft.FontWeight.BOLD
        )
        
        self.default_border = ft.Border.all(2, ft.Colors.GREY_400)
        self.active_border = ft.Border.all(2, ft.Colors.BLUE)
        
        self.container = ft.Container(
            content=self.text_control,
            alignment=ft.Alignment.CENTER,
            bgcolor=WAKU_COLORS[self.waku_number]["bg"],
            border=ft.Border.all(2, ft.Colors.GREY_400),
            width=circle_diameter,
            height=circle_diameter,
            border_radius=circle_diameter // 2,
        )
        
        super().__init__(
            content=self.container, 
            on_pan_update=self.handle_drag,
            **kwargs
        )
        
    def set_horse_number(self, new_number: int):
        self.waku_number = self.waku_map[new_number] 
        self.text_control.value = str(new_number) if new_number != 0 else "✕"
        self.text_control.color = WAKU_COLORS[self.waku_number]["text"]
        self.container.bgcolor = WAKU_COLORS[self.waku_number]["bg"]
        
    def set_selected(self, selected: bool):
        if selected:
            self.container.border = self.active_border
        else:
            self.container.border = self.default_border
    
    def handle_drag(self, e: ft.Event[ft.DragUpdateEvent[ft.GestureDetector]]):
        target_delta = e.local_delta
        
        next_left = self.left + target_delta.x
        next_top = self.top + target_delta.y
        
        next_central_x = next_left + CIRCLE_DIAMETER / 2
        next_central_y = next_top + CIRCLE_DIAMETER / 2
        
        left, top = self.calc_limit_func(next_central_x, next_central_y)
        self.left = left
        self.top = top
        self.update()
        
class MenuHorseButton(ft.Container):
    def __init__(self, horse_number: int, waku_map, on_click=None, 
                 circle_diameter=CIRCLE_DIAMETER, text_size=TEXT_SIZE, **kwargs):
        
        self.horse_number = horse_number
        self.waku_map = waku_map
        
        self.waku_number = self.waku_map[horse_number]
        
        self.text_control = ft.Text(
            str(horse_number),
            size=text_size, 
            color=WAKU_COLORS[self.waku_number]["text"], 
            weight=ft.FontWeight.BOLD
        )
        
        super().__init__(
            content=self.text_control,
            alignment=ft.Alignment.CENTER,
            bgcolor=WAKU_COLORS[self.waku_number]["bg"],
            border=ft.Border.all(2, ft.Colors.GREY_400),
            width=circle_diameter,
            height=circle_diameter,
            border_radius=circle_diameter // 2,
            on_click=on_click,
            **kwargs
        )
        
    def set_enabled(self, available: bool):
        if available:
            self.opacity = 1.0
        else:
            self.opacity = 0.5
        self.update()

class BlueMenuCounter(ft.PopupMenuButton):
    def __init__(self, label_suffix="回", initial_value=1, on_change_callback=None, **kwargs):
        self.value = initial_value
        self.suffix = label_suffix
        self.on_change_callback = on_change_callback

        # 表示用のテキスト
        self.text_display = ft.Text(
            f"{self.value}{self.suffix}", 
            color=ft.Colors.WHITE, 
            size=13, 
            weight=ft.FontWeight.BOLD
        )

        # ポップアップ内部の入力フィールド（高さを32pxに潰す）
        self.input_field = ft.TextField(
            value=str(self.value),
            width=50,
            height=32,
            dense=True,
            content_padding=5,
            text_size=12,
            text_align=ft.TextAlign.CENTER,
            keyboard_type=ft.KeyboardType.NUMBER,
            border=ft.Border.all(color=ft.Colors.SURFACE_CONTAINER_HIGHEST),
            on_submit=self._on_text_submit
        )

        super().__init__(
            content=ft.Row(
                [
                    self.text_display,
                    ft.Icon(ft.Icons.ARROW_DROP_DOWN, color=ft.Colors.WHITE, size=16)
                ],
                spacing=2,
                alignment=ft.MainAxisAlignment.CENTER
            ),
            # ポップアップの中身にカウンターと入力欄を同居させる
            items=[
                ft.PopupMenuItem(
                    content=ft.Row(
                        [
                            ft.IconButton(ft.Icons.REMOVE, icon_size=14, on_click=self._decrement, width=28, height=28),
                            self.input_field,
                            ft.IconButton(ft.Icons.ADD, icon_size=14, on_click=self._increment, width=28, height=28),
                        ],
                        spacing=4,
                        alignment=ft.MainAxisAlignment.CENTER,
                    )
                )
            ],
            **kwargs
        )

    def _increment(self, e):
        self.value += 1
        self._update_all()

    def _decrement(self, e):
        if self.value > 1:
            self.value -= 1
            self._update_all()

    def _on_text_submit(self, e):
        try:
            val = int(self.input_field.value)
            if val > 0:
                self.value = val
        except ValueError:
            pass
        self._update_all()

    def _update_all(self):
        self.text_display.value = f"{self.value}{self.suffix}"
        self.input_field.value = str(self.value)
        self.text_display.update()
        self.input_field.update()
        if self.on_change_callback:
            self.on_change_callback(self.value)

class RaceMenuBar(ft.Container):
    def __init__(self, race_id: RaceID, 
                 on_race_id_change=None,
                 **kwargs):
        super().__init__()
        
        # 独自保持データ
        self.race_id = race_id
        print(race_id)
        self.current_date = race_id.date
        self.current_jyo = race_id.jyo
        # self._set_race_nums(race_id.race_num)
        self.current_race_num = race_id.race_num
        self.current_kaiji = race_id.kaiji
        self.current_nichiji = race_id.nichiji
        self.on_race_id_change = on_race_id_change
        
        self.select_dates = self._set_selectable_dates()
    
        
        # 最上部の青いラインの見た目を再現
        self.bgcolor = "#2241A3"  # ネット競馬風のディープブルー
        self.height = 36          # 限界まで低く設定（36px）
        self.padding = ft.Padding.symmetric(horizontal=10)
        self.vertical_alignment = ft.CrossAxisAlignment.CENTER

        # --- パーツ1: 日付選択 ---
        self.date_text = ft.Text(self._display_date(self.current_date), color=ft.Colors.WHITE, size=13, weight=ft.FontWeight.BOLD)
        self.date_button = ft.PopupMenuButton(
            content=ft.Row(
                [
                    self.date_text,
                    ft.Icon(ft.Icons.ARROW_DROP_DOWN, color=ft.Colors.WHITE, size=16)
                ],
                spacing=2,
                alignment=ft.MainAxisAlignment.END
            ),
            items=[
                ft.PopupMenuItem(self._display_date(date), data=date, on_click=self._on_date_select) for date in self.select_dates
            ],
            width=75,
            style=ft.ButtonStyle(bgcolor=ft.Colors.RED, shape=ft.RoundedRectangleBorder(radius=0))
        )

        # --- パーツ2: 競馬場選択 ---
        self.track_text = ft.Text(self.current_jyo, color=ft.Colors.WHITE, size=13, weight=ft.FontWeight.BOLD)
        self.track_button = ft.PopupMenuButton(
            content=ft.Row(
                [
                    self.track_text,
                    ft.Icon(ft.Icons.ARROW_DROP_DOWN, color=ft.Colors.WHITE, size=16)
                ],
                spacing=2,
                alignment=ft.MainAxisAlignment.CENTER
            ),
            items=[
                ft.PopupMenuItem(content=jyo, data=jyo, on_click=self._on_jyo_select) for jyo in COURSE_DC.values() if jyo in CHIHO_COURSE_LIST or jyo in list(COURSE_DC.values())[1:11]
            ],
            width=50,
        )

        # --- パーツ3: 中央のカレンダーアイコン ---
        self.calendar_icon = ft.IconButton(
            icon=ft.Icons.CALENDAR_MONTH,
            icon_color=ft.Colors.WHITE,
            icon_size=18,
            padding=0,
            width=32,
            height=32,
            on_click=lambda e: print("DatePicker起動"),
            style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=0))
        )
        
        # --- パーツ4: 回次選択 ---
        self.kaiji_counter = BlueMenuCounter(
            label_suffix="回", initial_value=self.current_kaiji, 
            width=40,
            on_change_callback=self._on_kaiji_change)
        
        # --- パーツ5: 日次選択 ---
        self.nichiji_counter = BlueMenuCounter(
            label_suffix="日", initial_value=self.current_nichiji, 
            width=40,
            on_change_callback=self._on_nichiji_change)

        # --- パーツ6: レース切り替え ---
        self.race_text = ft.Text(f"{self.current_race_num}R", color=ft.Colors.WHITE, size=13, weight=ft.FontWeight.BOLD)
        self.race_button = ft.PopupMenuButton(
            content=ft.Row(
                [
                    self.race_text,
                    ft.Icon(ft.Icons.ARROW_DROP_DOWN, color=ft.Colors.WHITE, size=16)
                ],
                spacing=2,
                alignment=ft.MainAxisAlignment.END
            ),
            items=[
                ft.PopupMenuItem(f"{i+1}R", data=i+1, on_click=self._on_race_num_select) for i in range(12)
            ],
            width=40,
            style=ft.ButtonStyle(bgcolor=ft.Colors.RED, shape=ft.RoundedRectangleBorder(radius=0))
        )

        # # --- 1. 前のレースボタン（◀ 1R） ---
        # self.prev_race_btn = ft.Container(
        #     content=ft.Row(
        #         [
        #             ft.Icon(ft.Icons.ARROW_LEFT, color=ft.Colors.WHITE, size=16),
        #             ft.Text(f"{self.prev_race_num}R", color=ft.Colors.WHITE, size=13, weight=ft.FontWeight.BOLD),
        #         ],
        #         spacing=2,
        #         alignment=ft.MainAxisAlignment.CENTER
        #     ),
        #     on_click=self._on_prev_race_click,
        #     height=32,
        #     width=36
        # )

        # # --- 2. 次のレースボタン（3R ▶） ---
        # self.next_race_btn = ft.Container(
        #     content=ft.Row(
        #         [
        #             ft.Text(f"{self.next_race_num}R", color=ft.Colors.WHITE, size=13, weight=ft.FontWeight.BOLD),
        #             ft.Icon(ft.Icons.ARROW_RIGHT, color=ft.Colors.WHITE, size=16)
        #         ],
        #         spacing=2,
        #         alignment=ft.MainAxisAlignment.CENTER
        #     ),
        #     on_click=self._on_next_race_click,
        #     height=32,
        #     width=36
        # )
        
        # --- パーツ7: レースID表示 ---
        self.race_id_text = ft.Text(self.race_id.race_id, color=ft.Colors.WHITE, size=13, weight=ft.FontWeight.BOLD, text_align=ft.TextAlign.END)

        # 横一列に美しく整列
        self.content = ft.Row(
            controls=[
                self.date_button,
                ft.VerticalDivider(color=ft.Colors.WHITE_24, width=1, thickness=1), # 縦の区切り線
                self.track_button,
                ft.VerticalDivider(color=ft.Colors.WHITE_24, width=1, thickness=1),
                self.calendar_icon,
                ft.VerticalDivider(color=ft.Colors.WHITE_24, width=1, thickness=1),
                self.kaiji_counter,
                ft.VerticalDivider(color=ft.Colors.WHITE_24, width=1, thickness=1),
                self.nichiji_counter,
                ft.VerticalDivider(color=ft.Colors.WHITE_24, width=1, thickness=1),
                self.race_button,
                ft.VerticalDivider(color=ft.Colors.WHITE_24, width=1, thickness=1),
                ft.Container(expand=True),
                self.race_id_text,
            ],
            alignment=ft.MainAxisAlignment.START,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=10,
            **kwargs
        )
        
    # イベント関数
    def _on_date_select(self, e: ft.Event[ft.PopupMenuItem]):
        self.current_date = e.control.data
        self.date_button.content.controls[0].value = self._display_date(self.current_date)
        self.date_button.content.update()
        self._reset_race_id()
        print(f"日付が選択されました: {self.current_date}")
    
    def _on_jyo_select(self, e: ft.Event[ft.PopupMenuItem]):
        self.current_jyo = e.control.data
        self.track_text.value = self.current_jyo
        self._reset_race_id()
        self.track_text.update()
        print(f"競馬場が選択されました: {self.current_jyo}")
        
    def _on_kaiji_change(self, new_value: int):
        ''' 回次が変更されたときの処理 '''
        self.current_kaiji = new_value
        self._reset_race_id()
        print(f"回次が変更されました: {self.current_kaiji}回")
        
    def _on_nichiji_change(self, new_value: int):
        ''' 日次が変更されたときの処理 '''
        self.current_nichiji = new_value
        self._reset_race_id()
        print(f"日次が変更されました: {self.current_nichiji}日")
        
    def _on_race_num_select(self, e: ft.Event[ft.PopupMenuItem]):
        self.current_race_num = e.control.data
        self.race_text.value = f"{self.current_race_num}R"
        self.race_text.update()
        self._reset_race_id()
        print(f"レース番号が選択されました: {self.current_race_num}R")
    
    
    # 独自関数
    # def _set_race_nums(self, race_num: int):
    #     self.current_race_num = race_num
    #     self.prev_race_num = self.current_race_num - 1
    #     self.next_race_num = self.current_race_num + 1
    #     if not hasattr(self, 'prev_race_btn') or not hasattr(self, 'next_race_btn'):
    #         return
    #     self.prev_race_btn.content.controls[1].value = f"{self.prev_race_num}R"
    #     self.prev_race_btn.content.update()
    #     self.next_race_btn.content.controls[0].value = f"{self.next_race_num}R"
    #     self.next_race_btn.content.update()
    
    def _reset_race_id(self):
        ''' 現在のレースIDを取得 '''
        self.race_id = RaceID(
            self.current_date, 
            self.current_jyo, 
            self.current_kaiji, 
            self.current_nichiji, 
            self.current_race_num
        )
        
        if hasattr(self, 'race_id_text'):
            self.race_id_text.value = self.race_id.race_id
            self.race_id_text.update()
        
        if self.on_race_id_change:
            self.on_race_id_change(self.race_id)
            
    def _set_selectable_dates(self):
        for i in range(7):
            date = self.current_date - dt.timedelta(days=i)
            if date.weekday() == 5:
                first_saturday = date
                break
        return [first_saturday + dt.timedelta(days=i) for i in range(7)]
    
    def _display_date(self, date: dt.date) -> str:
        weekday_map = ["月", "火", "水", "木", "金", "土", "日"]
        return f"{date.month}/{date.day}({weekday_map[date.weekday()]})"
    
    
# main.py
import flet as ft
from PIL import Image
import requests
from io import BytesIO
import sqlite3
import datetime as dt

from behinds.constants import CIRCLE_DIAMETER, TEXT_SIZE, WAKU_COLORS, TRACK_IMAGE_URL_DICT, SURFACE_IMAGE_URL_DICT, SPLIT_INDEX_DICT, MIN_SPLIT_INDEX, ROOT_HEIGHT, TOTAL_HORSE_NUM, FORMATION_PANEL_RATIO, CONTAINER_PADDING, ROOT_IMAGE_WIDTH, ROOT_IMAGE_HEIGHT, ROOT_IMAGE_CELL, ROOT_IMAGE_OUTER_PIXNUM, ROOT_IMAGE_HEAD_PIXNUM, ROOT_IMAGE_CENTER_LINE_WIDTH, ROOT_IMAGE_SUB_LINE_WIDTH, ROOT_FORMATION_PANEL_HEIGHT, ROOT_SELECT_PANEL_ASPECT_RATIO, ROOT_IMAGE_ASPECT_RATIO, ROOT_FORMATION_PANEL_ASPECT_RATIO, ROOT_FORMATION_FRONT_PADDING, ROOT_FORMATION_BACK_PADDING, ROOT_FORMATION_INNER_PADDING, ROOT_FORMATION_OUTER_PADDING, CIRCLE_PADDING, CIRCLE_RADIUS, YOUBI_CARACTER_LIST

from behinds.parts import FormationHorseChip, MenuHorseButton, RaceMenuBar
from behinds.functions import Generate_umaban2waku_map
from behinds.data_struct import RaceID

import json

async def save_to_preferences(data_list: list[dict]):
    """【Flet 1.0完全対応版】非同期SharedPreferencesへ保存"""
    if not data_list: 
        return
    
    # 1. サービスのインスタンスを生成
    prefs = ft.SharedPreferences() #
    
    # 2. 保存用の固有キーを生成
    storage_key = f"pos_{data_list[0]['race_id']}"
    
    # 3. リストをjson文字列にシリアライズし、awaitで非同期保存
    serialized_data = json.dumps(data_list)
    await prefs.set(storage_key, serialized_data) #
    print(f"SharedPreferencesへ永続保存完了: {storage_key}")


async def load_from_preferences(race_id_str: str) -> list[dict]:
    """【Flet 1.0完全対応版】非同期SharedPreferencesから読込"""
    prefs = ft.SharedPreferences()
    storage_key = f"pos_{race_id_str}"
    
    # 存在チェックと値の取得をawaitで同期する
    if await prefs.contains_key(storage_key): #
        try:
            raw_data = await prefs.get(storage_key) #
            return json.loads(raw_data) if raw_data else []
        except Exception as e:
            print(f"デシリアライズエラー: {e}")
            return []
    return []


class FormationEditor(ft.Container):
    #-------------------------------------------------------------
    # 1. コンストラクタ
    #-------------------------------------------------------------
    def __init__(self, 
                 page: ft.Page,
                 total_horses=TOTAL_HORSE_NUM, turn="右", surface="ダート", 
                 height = ROOT_HEIGHT, 
                 **kwargs):
        
        self.root_page = page
        
        # レース条件
        self._set_first_race_id()
        self.total_horses = total_horses
        self.turn = turn
        self.surface = surface
        self.waku_map = Generate_umaban2waku_map(total_horses)
        
        # 見た目用変数の初期化
        
        # 各コントロールのサイズ規定
        self.container_height  = height
        self.panel_height      = self.container_height - CONTAINER_PADDING * 2
        
        self.select_panel_width = self.panel_height * ROOT_SELECT_PANEL_ASPECT_RATIO
        self.select_panel_height = self.panel_height
        
        self.formation_panel_width = self.select_panel_width * FORMATION_PANEL_RATIO
        self.formation_panel_height = self.formation_panel_width * ROOT_FORMATION_PANEL_ASPECT_RATIO
        
        self.display_panel_width = self.formation_panel_width
        self.display_panel_height = self.panel_height - self.formation_panel_height - CONTAINER_PADDING
        
        # 画像のURLを取得
        self.track_image_url = TRACK_IMAGE_URL_DICT[self.turn]
        self.surface_image_url = SURFACE_IMAGE_URL_DICT[self.surface]
        
        # 画像のサイズ規定
        response = requests.get(self.track_image_url)
        bg_image = Image.open(BytesIO(response.content))
        if bg_image.width != ROOT_IMAGE_WIDTH or bg_image.height != ROOT_IMAGE_HEIGHT:
            raise ValueError(f"Track image size is not as expected: {bg_image.size}")
        else:
            self.root_bg_image_width  = ROOT_IMAGE_WIDTH
            self.root_bg_image_height = ROOT_IMAGE_HEIGHT
            self.root_bg_image_aspect_ratio = ROOT_IMAGE_ASPECT_RATIO
            self.root_bg_formation_panel_height = ROOT_FORMATION_PANEL_HEIGHT
            self.root_bg_formation_front_padding = ROOT_FORMATION_FRONT_PADDING
            self.root_bg_formation_back_padding  = ROOT_FORMATION_BACK_PADDING
            self.root_bg_formation_inner_padding = ROOT_FORMATION_INNER_PADDING
            self.root_bg_formation_outer_padding = ROOT_FORMATION_OUTER_PADDING
        
        self.bg_image_scale_ratio = self.formation_panel_width / self.root_bg_image_width
        
        self.bg_image_width  = self.root_bg_image_width * self.bg_image_scale_ratio
        self.bg_image_height = self.root_bg_image_height * self.bg_image_scale_ratio
        self.bg_image_slide_height = self.bg_image_height - self.formation_panel_height
        
        self.formation_outer_padding = self.root_bg_formation_outer_padding * self.bg_image_scale_ratio + CIRCLE_PADDING + CIRCLE_RADIUS
        self.formation_inner_padding = self.root_bg_formation_inner_padding * self.bg_image_scale_ratio + CIRCLE_PADDING + CIRCLE_RADIUS
        self.formation_front_padding = self.root_bg_formation_front_padding * self.bg_image_scale_ratio + CIRCLE_PADDING + CIRCLE_RADIUS
        self.formation_back_padding  = self.root_bg_formation_back_padding  * self.bg_image_scale_ratio + CIRCLE_PADDING + CIRCLE_RADIUS
        
        self.upper_limit_dict = {
            "mukojomen": self.formation_outer_padding,
            "chokusen":  self.formation_inner_padding
        }
        
        self.under_limit_dict = {
            "mukojomen": self.formation_panel_height - self.formation_inner_padding,
            "chokusen":  self.formation_panel_height - self.formation_outer_padding
        }
        
        self.left_limit_dict = {
            "右": {"mukojomen": self.formation_back_padding,  "chokusen": self.formation_front_padding},
            "左": {"mukojomen": self.formation_front_padding, "chokusen": self.formation_back_padding},
        }
        self.right_limit_dict = {
            "右": {"mukojomen": self.formation_panel_width - self.formation_front_padding, 
                    "chokusen":  self.formation_panel_width - self.formation_back_padding},
            "左": {"mukojomen": self.formation_panel_width - self.formation_back_padding, 
                    "chokusen":  self.formation_panel_width - self.formation_front_padding},
        }
 
        # 状態変数の初期化
        self.active_chip = None
        self.current_mode = "mukojomen"
        
        # 馬番選択ボタン群の初期化
        self.menu_buttons_muko = self._create_menu_buttons()
        self.menu_buttons_choku = self._create_menu_buttons()
        self.menu_buttons = self.menu_buttons_muko
        
        # モード切替ボタンの初期化
        self.mode_button = ft.FilledButton("向正面", on_click=self.toggle_mode, height=30)
        
        # 左パネル（馬番選択ボタン群）の初期化
        self.umaban_select_muko = self._build_umaban_select_col(self.menu_buttons_muko)
        self.umaban_select_choku = self._build_umaban_select_col(self.menu_buttons_choku)
        
        self.menu_buttons_col_container = ft.Container(
            content=self.umaban_select_muko,
            border_radius=8,
            bgcolor=ft.Colors.SURFACE_CONTAINER_LOW,
            width=self.select_panel_width, height=self.select_panel_height,
            padding=10,
        )
        
        # 右上パネル（隊列図スタック）の初期化
        self.surface_image_layer = ft.Image(
            src=self.surface_image_url, fit=ft.BoxFit.FIT_WIDTH,
            width=self.bg_image_width, height=self.bg_image_height,
            top=0,
            )
        self.track_image_layer = ft.Image(
            src=self.track_image_url, fit=ft.BoxFit.FIT_WIDTH,
            width=self.bg_image_width, height=self.bg_image_height,
            top=0
            )
        
        self.chip_layer_muko = ft.Stack(
            width=self.formation_panel_width, height=self.formation_panel_height, top=0, visible=True)
        self.chip_layer_choku = ft.Stack(
            width=self.formation_panel_width, height=self.formation_panel_height, top=0, visible=False)
        
        self.chip_layer = self.chip_layer_muko  # アクティブなチップレイヤーを保持
        
        self.control_layer = ft.GestureDetector(on_tap_down=self.image_click)

        self.formation_area = ft.Stack(
            controls=[
                self.surface_image_layer,
                self.track_image_layer,
                self.control_layer,
                self.chip_layer_muko,
                self.chip_layer_choku,
            ],
        )
        
        self.formation_area_container = ft.Container(
                content=self.formation_area,
                bgcolor=ft.Colors.RED,
                border_radius=8,
                width=self.formation_panel_width,
                height=self.formation_panel_height, # test
            )
        
        # 右下パネル（レース情報パネル）の初期化
        text_content = "レース情報パネル\n日付、場名、レース番号の選択\n馬番の選択、馬名の表示\n選択馬番の馬主服表示\n"
        
        self.race_id_status_text = ft.Text(
            "Race ID: 未設定\n" + "\n" + text_content, 
            size=14, weight=ft.FontWeight.BOLD, color=ft.Colors.BLUE_400, expand=True,
            text_align=ft.TextAlign.START, 
        )
        
        self.select_container = RaceMenuBar(
            race_id = self.race_id,
            on_race_id_change=lambda new_id: self.root_page.run_task(self._handle_menu_race_id_change, new_id),
        )
        
        # ボタンクリック時、非同期関数をキックする構造にアジャスト
        async def on_save_click(e):
            current_positions = self.get_current_chip_positions()
            await save_to_preferences(current_positions)

        async def on_load_click(e):
            positions = await load_from_preferences(self.race_id)
            self.load_chip_positions(positions)
        
        self.function_buttons_col = ft.Column(
            controls=[
                self.mode_button,
                ft.FilledButton(" 保存 ", on_click=on_save_click, height=30),
                ft.FilledButton(" 読込 ", on_click=on_load_click, height=30),
                ],
            alignment=ft.MainAxisAlignment.START,
            width=100,
            spacing=5,
        )   
        
        display_panel_col = ft.Column(
            controls=[
                self.select_container,
                ft.Row(
                    controls=[self.race_id_status_text, self.function_buttons_col],
                    vertical_alignment=ft.CrossAxisAlignment.START,
                ),
            ],
            alignment=ft.CrossAxisAlignment.START,
            horizontal_alignment=ft.CrossAxisAlignment.START,
        )
        
        self.display_panel = ft.Container(
            content=display_panel_col,
            width=self.display_panel_width, height=self.display_panel_height,
            bgcolor=ft.Colors.SURFACE_CONTAINER_LOW,
            border_radius=8,
        )
        
        # 右パネル（隊列図スタック＋レース情報パネル）のレイアウト
        self.right_panels_col = ft.Column(
            controls=[
                self.formation_area_container,
                self.display_panel,
            ],
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=10
        )

        # 全体レイアウトの初期化
        editor_layout = ft.Row(
            controls=[
                self.menu_buttons_col_container, 
                self.right_panels_col,
                ],
            alignment=ft.MainAxisAlignment.CENTER, 
            vertical_alignment=ft.CrossAxisAlignment.CENTER)
        
        # コンテナの初期化
        super().__init__(
            content=editor_layout,
            width=self.select_panel_width + self.formation_panel_width + CONTAINER_PADDING * 3,
            height=self.container_height,
            bgcolor=ft.Colors.SURFACE_CONTAINER_HIGHEST,
            border_radius=16,
            padding=CONTAINER_PADDING,
            **kwargs
        )
        
        print(f"Container width: {self.width}, height: {self.height}")
        print(f"Menu buttons col panel width: {self.menu_buttons_col_container.width}, height: {self.menu_buttons_col_container.height}")
        print(f"Formation panel width: {self.formation_area_container.width}, height: {self.formation_area_container.height}")
        
    # -------------------------------------------------------------
    # 2. コンストラクタ補助関数（プライベート関数）
    # -------------------------------------------------------------
    def _create_menu_buttons(self) -> dict[int, MenuHorseButton]:
        return {
            i: MenuHorseButton(
                horse_number=i, waku_map=self.waku_map,
                on_click=lambda e, horse_number=i: self.on_umaban_select(horse_number)
            ) for i in range(1, self.total_horses+1)
        }
           
    def _build_umaban_buttons_col_list(self, menu_buttons_dict) -> list[ft.Row]:
        if self.total_horses <= MIN_SPLIT_INDEX:
            return [ft.Column(
                controls=list(menu_buttons_dict.values()), 
                alignment=ft.MainAxisAlignment.CENTER, spacing=5)]
        else:
            split_index = SPLIT_INDEX_DICT.get(self.total_horses, self.total_horses // 2)
            return [
                ft.Column(
                    controls=list(menu_buttons_dict.values())[split_index:], 
                    alignment=ft.MainAxisAlignment.CENTER, spacing=5),
                ft.Column(
                    controls=list(menu_buttons_dict.values())[:split_index], 
                    alignment=ft.MainAxisAlignment.CENTER, spacing=5)
            ]
            
    def _build_umaban_select_col(self, menu_buttons_dict):
        umaban_buttons_col_list = self._build_umaban_buttons_col_list(menu_buttons_dict)
                
        return ft.Column(
            controls=[
                ft.Row(
                    controls=umaban_buttons_col_list,
                    alignment=ft.MainAxisAlignment.CENTER,
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                    expand=True,
                    spacing=5,
                ),
            ],
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=10,
        )
        
    # -------------------------------------------------------------
    # 3. イベント関数
    # -------------------------------------------------------------
    def toggle_mode(self, e: ft.Event[ft.Button]):
        if self.current_mode == "mukojomen":
            self.current_mode = "chokusen"
            self.menu_buttons = self.menu_buttons_choku
            self.menu_buttons_col_container.content = self.umaban_select_choku
            self.mode_button.content = "直線"
            self.surface_image_layer.top = -self.bg_image_slide_height
            self.track_image_layer.top = -self.bg_image_slide_height
            self.chip_layer_muko.visible = False
            self.chip_layer_choku.visible = True
            self.chip_layer = self.chip_layer_choku
        else:
            self.current_mode = "mukojomen"
            self.menu_buttons = self.menu_buttons_muko
            self.menu_buttons_col_container.content = self.umaban_select_muko
            self.mode_button.content = "向正面"
            self.surface_image_layer.top = 0
            self.track_image_layer.top = 0
            self.chip_layer_muko.visible = True
            self.chip_layer_choku.visible = False
            self.chip_layer = self.chip_layer_muko
        self.update()      
    
    def formation_chip_on_tap_down(self, e: ft.Event[ft.Container]):
        if self.active_chip is not None:
            self.active_chip.set_selected(False)
        self.active_chip = e.control
        self.active_chip.set_selected(True)
        self.update()
    
    def formation_chip_on_double_tap(self, e: ft.Event[ft.Container]):
        target_chip = e.control
        removed_number = target_chip.text_control.value
        if removed_number != "✕":
            self.menu_buttons[int(removed_number)].set_enabled(True)
        if target_chip == self.active_chip:
            self.active_chip = None 
        self.chip_layer.controls.remove(target_chip)
        self.update()
        
    def image_click(self, e: ft.Event[ft.TapEvent[ft.GestureDetector]]):
        clicked_position = e.local_position
        
        left, top = self.calc_position_by_limit(clicked_position.x, clicked_position.y)
        
        new_temp_horse = FormationHorseChip(
            horse_number=0,
            calc_limit_func=self.calc_position_by_limit,
            waku_map=self.waku_map,
            left=left, top=top,
            on_tap_down=self.formation_chip_on_tap_down,
            on_double_tap=self.formation_chip_on_double_tap
        )
        
        self.chip_layer.controls.append(new_temp_horse)

        if self.active_chip is not None:
            self.active_chip.set_selected(False)
        self.active_chip = new_temp_horse
        self.active_chip.set_selected(True)
        
    def get_current_chip_positions(self) -> list[dict]:
        data_list = []
        for chip in self.chip_layer_muko.controls:
            data_list.append({
                "makedatetime": dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "race_id": self.race_id.race_id,
                "horse_number": int(chip.text_control.value) if chip.text_control.value != "✕" else 0,
                "waku_number":  chip.waku_number,
                "mode": "mukojomen",
                "x": (chip.left + CIRCLE_DIAMETER / 2) / self.bg_image_width,
                "y": (chip.top + CIRCLE_DIAMETER / 2) / self.bg_image_height,
                "edit_x": (chip.left + CIRCLE_DIAMETER / 2) / self.bg_image_width,
                "edit_y": (chip.top + CIRCLE_DIAMETER / 2) / self.bg_image_height,
            })
        for chip in self.chip_layer_choku.controls:
            data_list.append({
                "makedatetime": dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "race_id": self.race_id.race_id,
                "horse_number": int(chip.text_control.value) if chip.text_control.value != "✕" else 0,
                "waku_number":  chip.waku_number,
                "mode": "chokusen",
                "x": (chip.left + CIRCLE_DIAMETER / 2) / self.bg_image_width,
                "y": (chip.top + CIRCLE_DIAMETER / 2 + self.bg_image_slide_height) / self.bg_image_height,
                "edit_x": (chip.left + CIRCLE_DIAMETER / 2) / self.bg_image_width,
                "edit_y": (chip.top + CIRCLE_DIAMETER / 2) / self.bg_image_height,
            })
        return data_list
    
    def load_chip_positions(self, data_list: list[dict]) -> None:
        self.chip_layer_muko.controls.clear()
        self.chip_layer_choku.controls.clear()
        
        for data in data_list:
            horse_number = data["horse_number"]
            mode = data["mode"]
            x = data["edit_x"] * self.bg_image_width
            y = data["edit_y"] * self.bg_image_height
            
            if mode == "mukojomen":
                left, top = self.calc_position_by_limit(x, y)
                new_chip = FormationHorseChip(
                    horse_number=horse_number,
                    calc_limit_func=self.calc_position_by_limit,
                    waku_map=self.waku_map,
                    left=left, top=top,
                    on_tap_down=self.formation_chip_on_tap_down,
                    on_double_tap=self.formation_chip_on_double_tap
                )
                self.chip_layer_muko.controls.append(new_chip)
            elif mode == "chokusen":
                left, top = self.calc_position_by_limit(x, y)
                new_chip = FormationHorseChip(
                    horse_number=horse_number,
                    calc_limit_func=self.calc_position_by_limit,
                    waku_map=self.waku_map,
                    left=left, top=top,
                    on_tap_down=self.formation_chip_on_tap_down,
                    on_double_tap=self.formation_chip_on_double_tap
                )
                self.chip_layer_choku.controls.append(new_chip)
        
        self.update()
        
    def _set_first_race_id(self):
        today = dt.date.today()
        self.race_id = RaceID(today, "東京", 1, 1, 1)  # 初期化
        
    async def _handle_menu_race_id_change(self, new_race_id: RaceID):
        if self.chip_layer_muko.controls or self.chip_layer_choku.controls:
            await save_to_preferences(self.get_current_chip_positions())  # 現在のデータを保存
        self.chip_layer_muko.controls.clear()
        self.chip_layer_choku.controls.clear()
        self.race_id = new_race_id
        self.race_id_status_text.value = f"Race ID: {self.race_id.race_id}\n\n日付: {self.race_id.date}, 場名: {self.race_id.jyo}, レース番号: {self.race_id.race_num}R, 回次: {self.race_id.kaiji}回, 日次: {self.race_id.nichiji}日"
        self.update()
        
    # -------------------------------------------------------------
    # 4. イベント補助関数
    # -------------------------------------------------------------
    def calc_position_by_limit(self, root_x, root_y):
        self.upper_limit = self.upper_limit_dict[self.current_mode]
        self.under_limit = self.under_limit_dict[self.current_mode]
        self.left_limit = self.left_limit_dict[self.turn][self.current_mode]
        self.right_limit = self.right_limit_dict[self.turn][self.current_mode]
        
        root_x = self.left_limit if root_x < self.left_limit else root_x if root_x < self.right_limit else self.right_limit
        root_y = self.upper_limit if root_y < self.upper_limit else root_y if root_y < self.under_limit else self.under_limit
            
        output_x = root_x - CIRCLE_DIAMETER / 2
        output_y = root_y - CIRCLE_DIAMETER / 2
        
        return output_x, output_y

    def on_umaban_select(self, horse_number: int):
        if self.active_chip is None:
            return

        old_number = self.active_chip.text_control.value
        if old_number != "✕":
            self.menu_buttons[int(old_number)].set_enabled(True)
        
        self.active_chip.set_selected(False)
        self.active_chip.set_horse_number(horse_number)

        self.menu_buttons[horse_number].set_enabled(False)

        self.update()
    

def main(page: ft.Page):
    page.title = "隊列図テスト"
    position_dict = {}
    
    def apply_resize(e: ft.Event[ft.Page]):
        page.clean()
        
        print(f"Page width: {page.width}, height: {page.height}")
        
        if page.width < page.height:
            text_container = ft.Container(
                content=ft.Text("画面が縦長です。\n横長にしてご利用ください。", size=20, text_align=ft.TextAlign.CENTER),
                alignment=ft.Alignment.CENTER,
                expand=True
            )
            page.add(text_container)
        else:
            
            padding_container = ft.Container(
                width=50, height=page.height-20
            )
            
            formation_editor = FormationEditor(
                page=page,
                turn="右", surface="ダート", total_horses=18, 
                height=page.height - 20
            )
            final_container = ft.Container(
                content=ft.Row(
                    controls=[
                        padding_container,
                        formation_editor,
                        ]),
                alignment=ft.Alignment.CENTER,
            )
            page.add(final_container)
    
    page.on_resize = apply_resize
    apply_resize(None)  # 初期表示時に呼び出す
                
    
# -------------------------------------------------------------
# アプリの起動
# -------------------------------------------------------------

if __name__ == "__main__":
    ft.run(main)